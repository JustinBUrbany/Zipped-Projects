/*************************************************************
* Author:		Justin.Urbany
* Filename:		BackWardsIterator.h
* Date Created:	2/25/17
* Modifications:	3/1/17 -Added Comments
**************************************************************/
#pragma once
#include "ListIter.h"
/************************************************************************
* Class: backwards_Iter
*
* Purpose: This class is the interface for a list iterator
*
* Manager functions:
*	list_iter();
*	list_Iter(List<T> list);
*	list_Iter(list_Iter & copy);
*	~list_Iter();
*
*
* Methods:
*	void GetFirst:  Virutual
*	void MoveNext:  Virtual
*	void IsDone;  Virtual
*	void GetCurrent:  Virutal
*************************************************************************/
template<typename T>
class backwards_Iter : list_Iter<T>
{
public:
	backwards_Iter(List<T> list);
	backwards_Iter(backwards_Iter & copy);
	~backwards_Iter();
	backwards_Iter & operator =(backwards_Iter & rhs);
	void GetFirst();
	void MoveNext();
	bool IsDone();
	T  GetCurrent();
};
/**********************************************************************
* Purpose: The purpose of this function is to make a list iter
*
* Precondtion: called when making an iterator
*
* Postcondition: iterator is constructed
*
************************************************************************/
template<typename T>
inline backwards_Iter<T>::backwards_Iter(List<T> list)
{
	m_list = list;
}
/**********************************************************************
* Purpose: The purpose of this function is to make a list iter
*
* Precondtion: called when making an iterator
*
* Postcondition: iterator is constructed
*
************************************************************************/
template<typename T>
inline backwards_Iter<T>::backwards_Iter(backwards_Iter & copy)
{
	*this = copy;
}
/**********************************************************************
* Purpose: The purpose of this function is to destroy a list iter
*
* Precondtion: called when an iterator goes out of scope
*
* Postcondition: iterator is destroyed
*
************************************************************************/
template<typename T>
inline backwards_Iter<T>::~backwards_Iter()
{
}
/**********************************************************************
* Purpose: The purpose of this function is to assign a iterator
*			to another iterator
*
* Precondtion: called when iterator is assigned
*
* Postcondition: iterators are equal
*
************************************************************************/
template<typename T>
inline backwards_Iter<T> & backwards_Iter<T>::operator=(backwards_Iter & rhs)
{
	if (this != &rhs)
	{
		*this = rhs;
	}
	return *this;
}
/**********************************************************************
* Purpose: Gets the first element of a list
*
* Precondtion: called form iterator
*
* Postcondition: the first thing in the iterator
*
************************************************************************/
template<typename T>
inline void backwards_Iter<T>::GetFirst()
{
	m_current = m_list.getTail();
}
/**********************************************************************
* Purpose: Moves to next element in the list
*
* Precondtion: called from iterator
*
* Postcondition: moves to next element of iterator
*
************************************************************************/
template<typename T>
inline void backwards_Iter<T>::MoveNext()
{
	m_current = m_current->GetPrev();
}
/**********************************************************************
* Purpose: Checks if an iterator is done
*
* Precondtion: none
*
* Postcondition: returns true if is done
*
************************************************************************/
template<typename T>
inline bool backwards_Iter<T>::IsDone()
{
	bool done = false;
	if (m_current == nullptr)
	{
		done = true;
	}
	return done;
}
/**********************************************************************
* Purpose: Gets the data at the point in the slsit
*
* Precondtion: none
*
* Postcondition: data at that node is returned
*
************************************************************************/
template<typename T>
inline T backwards_Iter<T>::GetCurrent()
{
	return m_current->GetData();
}

