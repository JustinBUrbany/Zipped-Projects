/*************************************************************
* Author:		Justin.Urbany
* Filename:		Stub.cpp
* Date Created:	2/28/17
* Modifications:	3/1/17 -Added Comments
**************************************************************/
#define _CRTDBG_MAP_ALLOC
#define PATH_NAME 256
#include <iostream>
#include <experimental\filesystem>
#include <cstring>
#include <string.h>
#include "List.h"
#include "FowardIterator.h"
#include <crtdbg.h>
using std::string;
//using std::string::npos;
using std::cout;
using std::cin;
using std::endl;
using std::experimental::filesystem::path;
using std::experimental::filesystem::recursive_directory_iterator;
/**********************************************************************
* Purpose: The purpose of this function is to show the user valid
*			commands they can use to search for directories/files
*
* Precondtion: Some sort of invalid entry must be entered
*
* Postcondition: Displays listing of valid entries
*
************************************************************************/
void IncorrectEntry();
/*************************************************************
*
* Lab/Assignment: Lab 5-Directory
*
* Overview:
*	This lab will take in a Directory from command line argument
*		It will take that directory and put the whole thing
*		into a linked list then the user can type in a directory
*		with an extension giving and look for files of that type
*		or just see what is in that directory
* Input:
*   The input consists of the user entering in what they
*	are looking for.
*
* Output:
*   The ouptut of this program will display the whole path
*	of the directories or files that are found when the
*	search is completed
************************************************************/
int main(int argc, char * argv[])
{
	_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
	char command[PATH_NAME] = { '\0' };
	char * tokstr=nullptr;
	char * extension=nullptr;
	char temp[PATH_NAME] = { '\0' };
	string tempstr;
	size_t found;
	path directory{ argv[1] };


	if (is_directory(directory) && !is_empty(directory))
	{
		List<path> myfilesystem;
		recursive_directory_iterator directoryiter(directory), end;
		while (directoryiter != end)
		{
			myfilesystem.Append(directoryiter->path());
			++directoryiter;
		}
		forward_Iter<path> myfilesystemiter(myfilesystem);
		while (strcmp(command, "exit") != 0)
		{
			cout << "You are in " << argv[1] << " ";
			cin.ignore(cin.rdbuf()->in_avail());
			cin.getline(command, PATH_NAME);
			cin.ignore(cin.rdbuf()->in_avail());
			cin.clear();

			if (command[0] !='\0')
			{
				tokstr = strtok(command, " ");
				if (strcmp(tokstr, "list") == 0)
				{
					tokstr = strtok(nullptr, " ");
					if (tokstr != nullptr)
					{
						if (strcmp(tokstr, "-r") == 0)
						{
							tokstr = strtok(nullptr, " ");
							if (strncmp(tokstr, argv[1], strlen(argv[1])) == 0) 
							{
								if((extension=strstr(tokstr,"*."))!=nullptr)
								{
									extension = strtok(extension, "*");
									strcpy(temp, extension); //temp will have the extension for files you want to display
									tokstr = strtok(tokstr, "*"); //tokstr will have the path for the starting directory
									tokstr[strlen(tokstr) - 1] = { '\0' };
									cout << "All files that have the " << temp << "Extension and are in either " << tokstr << " directory or one of its subdirectory" << endl;
									for (myfilesystemiter.GetFirst(); !myfilesystemiter.IsDone(); myfilesystemiter.MoveNext())
									{
										//if(myfilesystemiter.GetCurrent().root_path() == static_cast<path>(tokstr))
										//{
										//	if(myfilesystemiter.GetCurrent().extension()==static_cast<path>(temp))
										//	{
										//		cout << myfilesystemiter.GetCurrent() << endl;
										//	}
										//}
										tempstr = myfilesystemiter.GetCurrent().string();
										if((static_cast<string>(tokstr).compare(0,strlen(tokstr),tempstr)))
										{
											if(myfilesystemiter.GetCurrent().extension()==static_cast<path>(temp))
											{
												cout << myfilesystemiter.GetCurrent() << endl;
											}
										}
									}
								}
								else
								{
									cout << "All directories, subdirectories and files in " << tokstr << "are listed below" << endl;
									for (myfilesystemiter.GetFirst(); !myfilesystemiter.IsDone(); myfilesystemiter.MoveNext())
									{
									/*	if (myfilesystemiter.GetCurrent().parent_path() == static_cast<path>(tokstr))
										{
											cout << myfilesystemiter.GetCurrent() << endl;
										}*/
										tempstr = myfilesystemiter.GetCurrent().string();
										if ((static_cast<string>(tokstr).compare(0, strlen(tokstr), tempstr)))
										{
												cout << myfilesystemiter.GetCurrent() << endl;
										}
									}
								}
							}
							else
							{
								IncorrectEntry();
							}

						}
						else if (strncmp(tokstr, argv[1], strlen(argv[1])) == 0)
						{
							if ((extension = strstr(tokstr, "*.")) != nullptr)
							{
								extension = strtok(extension, "*");
								strcpy(temp, extension); //temp will have the extension for files you want to display
								tokstr = strtok(tokstr, "*"); //tokstr will have the path for the starting directory
								tokstr[strlen(tokstr) - 1] = { '\0' };
								cout << "All the files that have the " << temp << " extension and are in " << tokstr << " directory are listed below." << endl;
								for (myfilesystemiter.GetFirst(); !myfilesystemiter.IsDone(); myfilesystemiter.MoveNext())
								{
									if (myfilesystemiter.GetCurrent().parent_path() == static_cast<path>(tokstr))
									{
										//cout << myfilesystemiter.GetCurrent().extension();
										if (myfilesystemiter.GetCurrent().extension() == static_cast<path>(temp))
										{
											cout << myfilesystemiter.GetCurrent() << endl;
										}
									}
								}
							}
							else
							{
								cout << "All directories and files in " << tokstr << "are listed below" << endl;
								for (myfilesystemiter.GetFirst(); !myfilesystemiter.IsDone(); myfilesystemiter.MoveNext())
								{
									if (myfilesystemiter.GetCurrent().parent_path() == static_cast<path>(tokstr))
									{
										cout << myfilesystemiter.GetCurrent() << endl;
									}
								}
							}
						}
						else
						{
							cout << "Any Directory or file that contains the string " << tokstr << "in your file system starting at " << argv[1] << "are listed below" << endl;
							for (myfilesystemiter.GetFirst(); !myfilesystemiter.IsDone(); myfilesystemiter.MoveNext())
							{
								tempstr=myfilesystemiter.GetCurrent().string();
								found = tempstr.find(static_cast<string>(tokstr), 0);
								if(found!=-1)
								{
									cout << myfilesystemiter.GetCurrent() << endl;
								}
							}

						}
					}
					else
					{
						IncorrectEntry();
					}
				}
				else if (strcmp(command, "exit") == 0)
				{
					cout << "Exiting Program" << endl;
				}
				else
				{
					IncorrectEntry();
				}
			}
			else
			{
				IncorrectEntry();
			}

		}
	}
	else
	{
		cout << "Isn't a directory or is an empty directory";
	}
	return 0;
}

void IncorrectEntry()
{
	cout << "Your command was incorrect: " << endl;
	cout << " 1) if you enter exit it will close the program." << endl;
	cout << " 2) Must start each command with list ." << endl;
	cout << " 3) If you want to display all files in subdirectories then must give -r after list ex:(list -r ) "<<endl;
	cout << " 4) Must specificy certain directory in which you want to start ex:(list c:\\test\\)" << endl;
	cout << " 5) if you want to display only certain file types then must specficy file type ex:(list c:\\test\\*.docx)." << endl;
	cout << " 6) list (string) will display any directory subdirectory or file that contains the string in it." << endl << endl;
}
