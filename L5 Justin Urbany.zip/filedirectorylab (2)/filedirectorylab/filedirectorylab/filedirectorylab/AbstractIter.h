/*************************************************************
* Author:		Justin.Urbany
* Filename:		AbstractIter.h
* Date Created:	2/25/17
* Modifications:	3/1/17 -Added Comments
**************************************************************/
#pragma once
/************************************************************************
* Class: Purely abstract Class abs_Iter
*
* Purpose: Interface for a iterator
*
* Manager functions:
*None
*
* Methods:
*	void GetFirst: Pure Virutual
*	void MoveNext: Pure Virtual
*	void IsDone; Pure Virtual
*	void GetCurrent: Pure Virutal
*************************************************************************/
template<typename T>
class abs_Iter
{
public:
	virtual void GetFirst() = 0;
	virtual void MoveNext() = 0;
	virtual bool IsDone() = 0;
	virtual T  GetCurrent() = 0;
};



