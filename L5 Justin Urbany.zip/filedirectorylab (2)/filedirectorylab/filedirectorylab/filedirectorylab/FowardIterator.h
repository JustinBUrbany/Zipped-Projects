/*************************************************************
* Author:		Justin.Urbany
* Filename:		ForwardIterator.h
* Date Created:	2/25/17
* Modifications:	3/1/17 -Added Comments
**************************************************************/
#pragma once
#include "BackwardsIterator.h"
/************************************************************************
* Class: forward_Iter
*
* Purpose: This class is the interface for a list iterator
*
* Manager functions:
*	list_iter();
*	list_Iter(List<T> list);
*	list_Iter(list_Iter & copy);
*	~list_Iter();
*
*
* Methods:
*	void GetFirst:  Virutual
*	void MoveNext:  Virtual
*	void IsDone;  Virtual
*	void GetCurrent:  Virutal
*************************************************************************/
template<typename T>
class forward_Iter : list_Iter<T>
{
public:
	forward_Iter(List<T> & list);
	forward_Iter(forward_Iter & copy);
	~forward_Iter();
	forward_Iter & operator =(forward_Iter & rhs);
	void GetFirst();
	void MoveNext();
	bool IsDone();
	T  GetCurrent();
};
/**********************************************************************
* Purpose: The purpose of this function is to make a list iter
*
* Precondtion: called when making an iterator
*
* Postcondition: iterator is constructed
*
************************************************************************/
template<typename T>
forward_Iter<T>::forward_Iter(List<T> & list)
{
	m_list = list;
}
/**********************************************************************
* Purpose: The purpose of this function is to make a list iter
*
* Precondtion: called when making an iterator
*
* Postcondition: iterator is constructed
*
************************************************************************/
template<typename T>
forward_Iter<T>::forward_Iter(forward_Iter & copy)
{
	*this = copy;
}
/**********************************************************************
* Purpose: The purpose of this function is to destroy a list iter
*
* Precondtion: called when an iterator goes out of scope
*
* Postcondition: iterator is destroyed
*
************************************************************************/
template<typename T>
inline forward_Iter<T>::~forward_Iter()
{
}
/**********************************************************************
* Purpose: The purpose of this function is to assign a iterator
*			to another iterator
*
* Precondtion: called when iterator is assigned
*
* Postcondition: iterators are equal
*
************************************************************************/
template<typename T>
forward_Iter<T> & forward_Iter<T>::operator=(forward_Iter & rhs)
{
	if (this != &rhs)
	{
		m_current = rhs.m_current;
		m_list = rhs.m_list;
	}
	return *this;
}
/**********************************************************************
* Purpose: Gets the first element of a list
*
* Precondtion: called form iterator
*
* Postcondition: the first thing in the iterator
*
************************************************************************/
template<typename T>
void forward_Iter<T>::GetFirst()
{
	m_current = m_list.getHead();
}
/**********************************************************************
* Purpose: Moves to next element in the list
*
* Precondtion: called from iterator
*
* Postcondition: moves to next element of iterator
*
************************************************************************/
template<typename T>
void forward_Iter<T>::MoveNext()
{
	m_current = m_current->GetNext();;
}
/**********************************************************************
* Purpose: Checks if an iterator is done
*
* Precondtion: none
*
* Postcondition: returns true if is done
*
************************************************************************/
template<typename T>
bool forward_Iter<T>::IsDone()
{
	bool done = false;
	if (m_current == nullptr)
	{
		done = true;
	}
	return done;
}
/**********************************************************************
* Purpose: Gets the data at the point in the slsit
*
* Precondtion: none
*
* Postcondition: data at that node is returned
*
************************************************************************/
template<typename T>
T  forward_Iter<T>::GetCurrent()
{
	return m_current->GetData();
}
