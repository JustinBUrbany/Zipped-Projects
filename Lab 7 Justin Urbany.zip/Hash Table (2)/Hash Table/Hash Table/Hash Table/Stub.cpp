/*************************************************************
* Author:		Justin.Urbany
* Filename:		Stub.cpp
* Date Created:	3/14/2017
* Modifications:	3/14/17 -Added Comments
**************************************************************/
#define _CRTDB_MAP_ALLOC
#include <iostream>
#include <string>
#include "HashTable.h"
using std::string;
using std::stoi;
using std::cout;
using std::cin;
using std::endl;
#include <crtdbg.h>

struct Book
{
	string m_title;
	string m_author;
	int m_pages;
};

int AciiHash(string Key);
void Dispaly(Book book);
int AnotherHash(string Key);
/*************************************************************
*
* Lab/Assignment: Lab 7- HashTable
*
* Overview: This lab was designed to test a hash table it will
*			create a hash table size 10 and test all the functionality
*			of the hash table class
*	
* Input:	This lab takes no input
*
* Output:	This lab will output all the books in the table
*			
*   
************************************************************/
int main()
{
	_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);

	Book temp = { "C++: An Active Learning Approach", "Randal Albert", 635 };
	Book temp1 = { "Rodeo for Dummies", "Calvin Caldwell", 1 };
	Book temp2 = { "temp2", "Todd", 1 };
	Book temp3 = { "temp3", "Jesse", 1 };
	Book temp4 = { "temp4", "Troy", 1 };
	Book temp5 = { "temp5", "Mark", 1 };
	Book temp6 = { "temp6", "Phil", 1 };
	Book temp7 = { "temp7", "Soo", 1 };
	Book temp8 = { "temp8", "Lucy", 1 };
	Book temp9 = { "temp9", "Mandy", 1 };
	Book temp10 = { "temp10", "Alicia", 1 };
	Book temp11= { "temp11", "LAST PERSON", 1 };
	HashTable<string, Book> table1;
	HashTable<string, Book> table(10);

	table.setHash(AciiHash);


	table.Insert("7063757235",temp);
	table.Insert("7063757236",temp1);
	table.Insert("7063757237",temp2);
	table.Insert("7063757238",temp3);
	table.Insert("7063757239", temp4);
	table.Insert("7063757230", temp5);
	table.Insert("7063757241", temp6);
	table.Insert("7063757242", temp7);
	table.Insert("7063757243", temp8);
	table.Insert("7063757244", temp9);
	table.Insert("7063757245", temp10);
	table.Insert("7063757246", temp11);

	cout << table["7063757235"].m_title << endl;
	cout << table["7063757236"].m_title << endl;
	cout << table["7063757237"].m_title << endl;

	table.traverse(Dispaly);
	table.Delete("7063757235");
	table.traverse(Dispaly);

	table1 = table;
	table.setHash(AnotherHash);
	table.traverse(Dispaly);

	HashTable<string, Book> table2(table);

	table2.traverse(Dispaly);

	

	return 0;
}
/**********************************************************************
* Purpose: The purpose is to set a has for a hash table
*
* Precondtion: Takes in a string
*
* Postcondition: returns an integer value
* *
************************************************************************/
int AciiHash(string Key)
{
	int location = 0;

	for (int i = 0; i < Key.length(); i++)
	{
		location += static_cast<int>(Key[i]);
	}
	return location;
}
/**********************************************************************
* Purpose: The purpose is to display all the elements of a book
*
* Precondtion: Takes in abook
*
* Postcondition: Displays all the title author and pages of the book
* 
************************************************************************/
void Dispaly(Book book)
{
	cout << book.m_title << endl;
	cout << book.m_author << endl;
	cout << book.m_pages << endl;
}
/**********************************************************************
* Purpose: The purpose is to set a has for a hash table
*
* Precondtion: Takes in a string
*
* Postcondition: returns an integer value
* *
************************************************************************/
int AnotherHash(string Key)
{
	int x = Key.length();
	x += 7;
	x *= 22;
	x /= 3;

	return x;
}
