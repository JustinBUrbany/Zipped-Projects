/*************************************************************
* Author:		Justin.Urbany
* Filename:		HashTable.h
* Date Created:	3/14/2017
* Modifications:	3/14/17 -Added Comments
**************************************************************/
#pragma once
#include <vector>
#include <list>
#include "Exception.h"
using std::vector;
using std::list;
using std::pair;
using std::cout;
/************************************************************************
* Class: HashTable
*
* Purpose: Hash tables purpose is to organize data in a unique way
*			so that quick acess is available with a large amount of
*			data
*
* Manager functions:
*	HashTable();
*	HashTable(int size);
*	HashTable(const HashTable & copy);
*	HashTable & operator=(const HashTable & rhs);
*	~HashTable();
*
* Methods:
*	void Insert(K key, V value);
*	void setHash(int(*has)(K key));
*	V operator [](K key);
*	void Delete(K key);
*	void traverse(void(*visit)(V value));
*	int getKeyLocation(K key);
*	void rehash(int(*has)(K key));
*
*************************************************************************/
template<typename K, typename V>
class HashTable
{
public:
	HashTable();
	HashTable(int size);
	HashTable(const HashTable & copy);
	HashTable & operator=(const HashTable & rhs);
	~HashTable();

	void Insert(K key, V value);
	void setHash(int(*has)(K key));
	V operator [](K key);
	void Delete(K key);
	void traverse(void(*visit)(V value));
private:
	
	vector<list<pair<K, V>>> m_table;
	int (*Hashfnc)(K key);
	int getKeyLocation(K key);
	void rehash(int(*has)(K key));
};
/**********************************************************************
* Purpose: Creates a Hash table with intialize size of 10
*
* Precondtion:none
*
* Postcondition: Hash table has size of 10
*
************************************************************************/
template<typename K, typename V>
inline HashTable<K, V>::HashTable()
{
	m_table.resize(10);
}
/**********************************************************************
* Purpose: Makes a hash table with the passed in size
*
* Precondtion: pass in the size
*
* Postcondition: hash table is the passed in size
*
************************************************************************/
template<typename K, typename V>
inline HashTable<K, V>::HashTable(int size)
{
	m_table.resize(size);
}
/**********************************************************************
* Purpose: creates a copy of a hash table
*
* Precondtion: takes in the copy
*
* Postcondition: both sides are the same
*
************************************************************************/
template<typename K, typename V>
inline HashTable<K, V>::HashTable(const HashTable & copy)
{
	m_table = copy.m_table;
}
/**********************************************************************
* Purpose: assign one hash table to another hash table
*
* Precondtion: pass in the table to be assigned
*
* Postcondition: both sides are equal
*
************************************************************************/
template<typename K, typename V>
inline HashTable<K, V> & HashTable<K, V>::operator=(const HashTable & rhs)
{
	if (this != &rhs)
	{
		m_table = rhs.m_table;
	}
	return *this;
}
/**********************************************************************
* Purpose: Makes class canonical
*
* Precondtion: called when going out of scope
*
* Postcondition: cleans up any memory hash table was using
*
************************************************************************/
template<typename K, typename V>
inline HashTable<K, V>::~HashTable()
{
}
/**********************************************************************
* Purpose: Insert a key value pair into the table
*
* Precondtion: pass in the key and the value to the function
*
* Postcondition: either insert the key and value or throw an exception
*
************************************************************************/
template<typename K, typename V>
inline void HashTable<K, V>::Insert(K key, V value)
{
	pair<K, V> newpair(key,value);
	try
	{
		int place = getKeyLocation(key);
		m_table[place].push_back(newpair);
	}
	catch (Exception & exception)
	{
		cout << exception.getMessage();
	}
}
/**********************************************************************
* Purpose: Sets the hash function for the hash table
*
* Precondtion: pass in the function
*
* Postcondition: the hash tables hash function set and rehashed if
*					necessary
*
************************************************************************/
template<typename K, typename V>
inline void HashTable<K, V>::setHash(int(*has)(K key))
{
	Hashfnc = has;
	if (!m_table.empty())
	{
		rehash(has);
	}
}
/**********************************************************************
* Purpose: The purpose of this function is to pass in a key and
* 				get the value associated with the key
*
* Precondtion: pass in the key in the subscript operator
*
* Postcondition: throw exception if not found if found return the value
*
************************************************************************/
template<typename K, typename V>
inline V HashTable<K, V>::operator[](K key)
{
	int location = getKeyLocation(key);
	typename list<pair<K, V>>::iterator l_iterator=m_table[location].begin();

	while (l_iterator != m_table[location].end() && (*l_iterator).first != key)
	{
		++l_iterator;
	}
	if (l_iterator == m_table[location].end())
	{
		throw Exception("Not in your table");
	}

	return (*l_iterator).second;
}
/**********************************************************************
* Purpose: If the key is in the table then delete the key
*
* Precondtion: pass in the key find the position 
*
* Postcondition: remove the pair for the key if found else throw exception
*
************************************************************************/
template<typename K, typename V>
inline void HashTable<K, V>::Delete(K key)
{
	int position = getKeyLocation(key);
	typename list<pair<K, V>>::iterator l_iterator = m_table[position].begin();
	while(l_iterator != m_table[position].end() && (*l_iterator).first != key)
	{
		++l_iterator;
	}
	if(l_iterator != m_table[position].end())
	{
		m_table[position].erase(l_iterator);
	}
	else
	{
		throw Exception ( "That key wasn't in your table");
	}
}
/**********************************************************************
* Purpose: The purpose of this function is to go through the whole table
*			and do whatever functionality that is passed in
*
* Precondtion: pass in the function to be preformed
*
* Postcondition: go through the whole table preform the function on each
*					value in every pair
*
************************************************************************/
template<typename K, typename V>
inline void HashTable<K, V>::traverse(void(*visit)(V value))
{
	for(int i=0; i<m_table.size(); ++i)
	{
		typename list<pair<K, V>>::iterator l_iterator=m_table[i].begin();
		while(l_iterator != m_table[i].end())
		{
			visit((*l_iterator).second);
			++l_iterator;
		}
	}
}
/**********************************************************************
* Purpose: Preforms the Hash Function on the table and gets the location
*			for a key
*
* Precondtion: Pass in the key
*
* Postcondition: Return the integer value that repersents the location
*				in the hash table
*
************************************************************************/
template<typename K, typename V>
inline int HashTable<K, V>::getKeyLocation(K key)
{
	int location=0;

	location = Hashfnc(key);

	return location % m_table.size();
}
/**********************************************************************
* Purpose: Change the hash function for the table set the data for the
*				new function
*
* Precondtion: Takes in a has function
*
* Postcondition: Table must be set with the new function
*
************************************************************************/
template<typename K, typename V>
inline void HashTable<K, V>::rehash(int(*has)(K key))
{
	int place = -1;
	vector<list<pair<K, V>>> temp;
	temp.resize(m_table.size());
	list<pair<K, V>> iterplace;
	typename list<pair<K, V>>::iterator l_iterator;
	for (int i = 0; i < m_table.size(); ++i)
	{
		//iterplace = m_table[i];
		l_iterator = m_table[i].begin();
		for (; l_iterator != m_table[i].end(); ++l_iterator)
		{
			place = getKeyLocation((*l_iterator).first);
			temp[place].push_back((*l_iterator));
		}
	}
	m_table = temp;
}
