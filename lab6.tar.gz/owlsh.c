#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/wait.h>
#include <sys/types.h>
#define INPUT_LEN 512

int main(int argc, char * argv[], char *envp[])
{
    char user[50];
    int output=STDOUT_FILENO;
    int myexit=0;
    char *tokenstr;
    char *inputstring;
    char getstr[INPUT_LEN]={'\0'};
    char getcommand[INPUT_LEN]={'\0'};

    sprintf(user, "owlsh %s>> ", getenv("LOGNAME"));
    
    while(myexit==0)
    {
        write(output, user,strlen(user));
        inputstring =  fgets(getstr,INPUT_LEN,stdin);
        
        if(inputstring==NULL) //kill switch
        {
            exit(0);
        }

        getstr[strlen(getstr)-1]=0;

        if(strcmp(getstr, "exit")==0)
        {
            exit(0);
        }

           if(strlen(getstr)!=0)
           {
               tokenstr=strtok(getstr, " ");//get first command on stdin
               strcpy(getcommand, tokenstr);//copy the tokenized string
               
               if(strcmp(getcommand, "help")==0)
               {
                   printf("help will print this\n cntrl D will exit \n exit will exit \n");
                   printf("cd will change directory\npwd will print the workind directory\n"); 
               }
               else  if(strcmp(getcommand,"cd")==0)
               {
                   tokenstr=strtok(NULL, " "); // get the rest of the line 
                   chdir(tokenstr);  //change to the new directory
               }
               else  if(strcmp(getcommand, "pwd")==0)
               {
                   getcwd(getstr, INPUT_LEN);
                   printf(getstr); //Prints the current working directory path
               }
               else
               {
                   int status;
                   pid_t child;
                   int _argc=0;
                   char **_argv;
                   
                   child=fork();
                   if(child == 0)
                   {
                       _argv=(char**)malloc(sizeof(char*));
                       _argv[_argc]=strdup(getcommand);
                       while((tokenstr=strtok(NULL, " ")) != NULL)//Until the end of the Input
                       {
                           _argc++;
                           _argv=(char**)realloc(_argv,(_argc+1)*sizeof(char*));
                           _argv[_argc]=strdup(tokenstr);
                       }
                       _argc++;
                       _argv=(char**)realloc(_argv,(_argc+1)*sizeof(char*));
                       _argv[_argc]=NULL;

                       status =execvp(_argv[0], _argv);
                       exit(status);

                   }
                   else
                   {
                       child=wait(&status);
                   }
                   
               }
              
       }

    }
    
    return 0;
}
