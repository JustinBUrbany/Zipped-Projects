#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <utime.h>

void show_help(void);

int main(int argc, char * argv[])
{
    struct stat buffer;
    struct utimbuf timebuffer;
    int opt;
    int verbose=0;
    int filein=-1;
    int fileout=-1;
    int inputrecieved=0;
    int outputrecieved=0;
   const  char * outputfilename;
    int flags={O_WRONLY | O_CREAT | O_TRUNC};

    while((opt=getopt(argc,argv, "i:o:hv")) !=-1)
    {
        switch(opt)
        {
        case 'h':
            show_help();
            break;
        case 'v':
            verbose=1;
            break;
        case 'i':
            inputrecieved=1;
            filein=open(optarg,O_RDONLY);
            break;
        case 'o':
            outputrecieved=1;
            outputfilename=optarg;
            fileout=open(optarg, flags);
            break;
        }
    }

    if(inputrecieved==0 || outputrecieved==0)
    {
        if(verbose==1)
        {
            fprintf(stderr, "Either the input or output file name was not specified.");
        }
        show_help();
    }
    
    fstat( filein, &buffer);
    fchmod(fileout, buffer.st_mode);
    timebuffer.actime=buffer.st_atime;
    timebuffer.modtime=buffer.st_mtime;

    utime(outputfilename, &timebuffer);
//    futime(fileout,

    return 0;
}


void show_help(void)
{
    printf("-h command will show the help and give the following message\n");
    printf("-v command will put you in verbose mode and print extra information to stderr\n");
    printf("if the -i or the -o commands are not given you will come to the help\n");
    printf("YOU MUST USE the -i and -o commands followed by filenames\n -i is for input and -o is for output");
    exit(1);
}



