#include <iostream>
using std::cout;
using std::endl;
#include "card.h"
#include <iostream>
using std::cin;
//Almost Christmas!
/**********************************************************************
* Purpose:Multi arg constructor intialize suit and rank of a card
*
* Precondition: pass in a suit and a rank
*
* Postcondition: intialize the object
*
************************************************************************/
Card::Card(Rank rank, Suit suit) : m_rank(rank), m_suit(suit)
{ }
/**********************************************************************
* Purpose:The purpose of this function is to display the card to the
screen
*
* Precondition: be called within a card object
*
* Postcondition: have displayed a card to the screen
*
************************************************************************/
void Card::DisplayCard()
{

	const char*rank_txt[] = { "Ace","Deuce", "Trey", "Four", "Five", "Six", "Seven", "Eight",
		"Nine", "Ten", "Jack", "Queen","King" };

	cout << rank_txt[m_rank - 1] << " of " << static_cast<char>(m_suit);

}
/**********************************************************************
* Purpose:default destructor delete a card clean up memory
*
* Precondition: called when a card is going out of close
*
* Postcondition: the card no longer exsits
*
************************************************************************/
Card::~Card()
{

}
/**********************************************************************
* Purpose:This function is to set the rank of your cards private member
rank
*
* Precondition: called within a card and pass in a rank
*
* Postcondition: set m_rank to the rank
*
************************************************************************/
void Card::SetRank(Rank rank)
{
	m_rank = rank;
}
/**********************************************************************
* Purpose:This function is to set the suit of your cards data member
suit
*
* Precondition:called within a card and pass in a suit
*
* Postcondition: set the private member suit to the value that was
passed in
*
************************************************************************/
void Card::SetSuit(Suit suit)
{
	m_suit = suit;

}
/**********************************************************************
* Purpose: Returns thte private rank member of your cards
*
* Precondition: get called within a card object
*
* Postcondition: return the private data member m_rank
*
************************************************************************/
Card::Rank Card::PlayerGetRank()
{
	if (m_rank == KING || m_rank == QUEEN || m_rank == JACK)
	{
		m_rank = TEN;
	}
	if (m_rank == ACE)
	{
		int selection = 0;
		cout << "Do you want your ace to be 1 or 11?(Enter 0 for 1)";
		cin >> selection;
		if (selection == 0)
		{
			m_rank = ACE;
		}
		else
		{
			m_rank = JACK;
		}
	}

	return m_rank;

}
Card::Rank Card::GetRank()
{
	if (m_rank == KING || m_rank == QUEEN || m_rank == JACK)
	{
		m_rank = TEN;
	}
	if (m_rank == ACE)
	{
		m_rank = JACK;
	}
	return m_rank;
}

Card::Rank Card::DealerGetRank(int currentvalue)
{
	if (m_rank == KING || m_rank == QUEEN || m_rank == JACK)
	{
		m_rank = TEN;
	}
	if(currentvalue>17 && m_rank==ACE)
	{
		m_rank = JACK;
	}
	return m_rank;
}
/**********************************************************************
* Purpose:This is a getter for the card class that returns the private
member m_suit
*
* Precondition: get called within a card object
*
* Postcondition: must return the private member m_suit
*
************************************************************************/
Card::Suit Card::GetSuit()
{

	return m_suit;

}