#include "hand.h"

#ifndef DEALER_H
#define DEALER_H

class Dealer
{
public:
	Dealer();
	void Showfirst();
	void Newhand();
	void ShowCards();
	int GetIntialValue();
	int GetDealersCurrentValue(int checkace);
	void Deal(Card hand);
	~Dealer();

private:
	Hand dealershand;
};


#endif DEALER_H
