#include "Dealer.h"
#include <iostream>
using std::cout;
using std::endl;
Dealer::Dealer()
{
}

void Dealer::Showfirst()
{
	cout << "Dealers first card is:";
	dealershand.showdealersfirstcard(0);
	cout << endl;
}

void Dealer::Newhand()
{
	dealershand.DeleteHand();
}

void Dealer::ShowCards()
{
	dealershand.showcard();
}

int Dealer::GetIntialValue()
{
	return dealershand.DealersIntialValue();
}

int Dealer::GetDealersCurrentValue(int checkace)
{
	return dealershand.DealersHandValue(checkace);
}

void Dealer::Deal(Card hand)
{
	dealershand.add(hand);
}



Dealer::~Dealer()
{
}
