#include "Bankroll.h"
#include "Dealer.h"
#include "Player.h"
#include "deck.h"

#ifndef BLACKJACK_H
#define BLACKJACK_H

class BlackJack
{
public:
	BlackJack(int stack);
	void PromptUser();
	bool PlayerPrompt(int & bet);
	~BlackJack();

private:
	Bankroll yourstack;
	Dealer m_dealer;
	Player m_player;
	Deck m_deck;
	bool m_push = false;
};

#endif
