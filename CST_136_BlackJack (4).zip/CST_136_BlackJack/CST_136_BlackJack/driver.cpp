#include <iostream>
#include "blackjack.h"

int main()
{
	const int start = 200;
	BlackJack game(start);
	game.PromptUser();

	return 0;
}