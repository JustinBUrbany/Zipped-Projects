#include "Player.h"
#include <iostream>
using std::cout;
using std::endl;
Player::Player()
{
}

void Player::ShowCards()
{
	playershand.showcard();
}

void Player::Newhand()
{
	playershand.DeleteHand();
}

void Player::hit(Card newcard)
{
	playershand.add(newcard);
}

int Player::GetValue()
{
	return playershand.PlayerHandValue();
}

/*bool Player::Checkforpair()
{
	return playershand.Checkforapair();
}*/

void Player::Deal(Card hand)
{
	playershand.add(hand);
}

Player::~Player()
{
}
