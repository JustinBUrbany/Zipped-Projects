#ifndef DECK_H
#define DECK_H

#include "card.h"
#include "random.h"
/* "Debugging is twice as hard as writing the code in the first place. Therefore, if you write the code as cleverly as possible, you are, by definition, not smart enough to debug it." - Brian W.Kernighan. */
/************************************************************************
* Class: Deck
*
* Purpose: The purpose of this class is to create a deck that can hold
a deck of cards so that a game can be played with it
*
* Manager functions:
shuffle(): shuffles the cards in the deck
deal() deal the cards per deck
*
* Data_members:
m_deck[52] holds all the cards you have
rand used to get random numbers

*************************************************************************/
class Deck
{

public:
	Deck();
	void Shuffle();
	Card Deal();
	~Deck();
private:
	// Replace Card deck_[51] -- seemws never really worked right
	// OLD  -> Card deck_[51];
	//TODO: Needs updating to this pointer stuff - important
	Card ** m_deck;

	// Not sure if I need the static or not here
	Random rand;


	static int m_currentcard;
};

#endif 