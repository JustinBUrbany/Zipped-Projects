#include "card.h"
#ifndef HAND_H
#define HAND_H

class Hand
{
public:
	Hand();
	void add(Card newcard);
	void showcard();
	void DeleteHand();
	int PlayerHandValue();
	int DealersIntialValue();
	//bool Checkforapair();
	int DealersHandValue(int checkace);
	void showdealersfirstcard(int cardnumber);

	~Hand();


private:
	Card * yourhand=nullptr;
	int numberofcards = 0;
};


#endif
