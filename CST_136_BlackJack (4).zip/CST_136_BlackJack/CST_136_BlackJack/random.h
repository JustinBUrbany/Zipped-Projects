#ifndef RANDOM_H
#define RANDOM_H
/*****************************************************************
* Random Class
*  Filename:  random.hpp
*  Feel free to use your lab - or develop your own or use another one
Purpose: is to create a random number generator and use it to
randomly shuffle cards
function:
GetRandom: takes a number and returns a new number used for random
ability
******************************************************************/
class Random
{
public:
	Random()
	{ // Seed for random-number generation 
		srand(0);
	}
	// rand returns a pseudorandom number, as described above. 
	// The rand function returns a pseudorandom integer in the 
	// range 0 to RAND_MAX. Use srand function to seed the 
	// pseudorandom-number generator before calling rand. BLAH BLAH BLAH ...
	unsigned GetRandom(int n) const { return rand() % n; }
};
#endif
