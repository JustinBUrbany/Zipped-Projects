#ifndef PLAYER_H
#define PLAYER_H
#include "hand.h"

class Player
{
public:
	Player();
	void ShowCards();
	void Newhand();
	void hit(Card newcard);
	int GetValue();
	//bool Checkforpair();
	void Deal(Card hand);
	~Player();
	
private:
	Hand playershand;
};


#endif