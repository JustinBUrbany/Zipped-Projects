#include "hand.h"
#include <iostream>
using std::cout;
using std::endl;
Hand::Hand()
{
}

void Hand::add(Card newcard)
{
	Card * temp = new Card[numberofcards + 1];
	for (int i = 0; i < numberofcards; i++)
	{
		temp[i] = yourhand[i];
	}
	temp[numberofcards] = newcard;
	delete[]yourhand;
	yourhand = temp;
	numberofcards++;
}

void Hand::showcard()
{
	for (int i = 0; i < numberofcards; i++)
	{
		yourhand[i].DisplayCard();
		cout << endl;
	}
}
void Hand::showdealersfirstcard(int cardnumber)
{
	yourhand[cardnumber].DisplayCard();
}
void Hand::DeleteHand()
{
	delete[]yourhand;
	yourhand = nullptr;
	numberofcards = 0;
}
/*bool Hand::Checkforapair()
{
	bool pair = false;
	int value1 = 0;
	int value2 = 0;
	value1 = yourhand[0].PlayerGetRank();
	value2 = yourhand[1].PlayerGetRank();
	if (value1 == value2)
	{
		pair = true;
	}

	return pair;
}*/
int Hand::PlayerHandValue()
{
	int value = 0;
	for (int i = 0; i < numberofcards; i++)
	{
		value += yourhand[i].PlayerGetRank();
	}
	cout << value << endl;
	return value;
}

int Hand::DealersIntialValue()
{
	int value = 0;
	for (int i = 0; i < numberofcards; i++)
	{
		value += yourhand[i].GetRank();
	}
	cout << value << endl;
	return value;
}

int Hand::DealersHandValue(int checkace)
{
	int value = 0;
	for (int i = 0; i < numberofcards; i++)
	{
		value += yourhand[i].DealerGetRank(checkace);
	}
	cout << value << endl;
	return value;
}

Hand::~Hand()
{
	delete[]yourhand;
}
