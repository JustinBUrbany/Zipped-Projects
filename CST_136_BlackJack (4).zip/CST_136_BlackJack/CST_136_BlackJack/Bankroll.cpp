#include "Bankroll.h"

Bankroll::Bankroll(int stack): m_currentstack(stack)
{
}

int Bankroll::Getroll()
{
	return m_currentstack;
}

void Bankroll::Setroll(int stack)
{
	m_currentstack += stack;
}

Bankroll::~Bankroll()
{
}
