#ifndef BANKROLL_H
#define BANKROLL_H


class Bankroll 
{
public:
	Bankroll(int stack);
	int Getroll();
	void Setroll(int stack);
	~Bankroll();

private:
	int m_currentstack;

};


#endif