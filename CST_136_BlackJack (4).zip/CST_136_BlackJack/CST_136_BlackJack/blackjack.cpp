#include <iostream>
using std::cout;
using std::cin;
using std::endl;


#include "blackjack.h"
//#include "Bankroll.h"

BlackJack::BlackJack(int stack): yourstack(stack)
{

}

void BlackJack::PromptUser()
{
	int selection = 0;
	int bet = 0;
	bool winorlose = false;
	while (yourstack.Getroll() && selection != 2)
	{
		m_push = false;
		cout << "Ready to test your luck?" << endl;
		cout << "You current stack is: " << yourstack.Getroll() << endl;
		cout << "1) Play a hand" << endl;
		cout << "2) Quit before you lose it all" << endl;
		cin >> selection;
		switch (selection)
		{
		case 1:
			do
			{
				cout << "We don't run on credit and take only whole numbers" << endl;
				cout << "Enter in how much you are going to bet: ";
				cin >> bet;
				if (bet > yourstack.Getroll())
				{
					cout << "You don't have that much to bet You only have: " << yourstack.Getroll();
				}
			} while (bet > yourstack.Getroll());

			m_deck.Shuffle();
			m_dealer.Deal(m_deck.Deal());
			m_player.Deal(m_deck.Deal());
			m_dealer.Deal(m_deck.Deal());
			m_player.Deal(m_deck.Deal());
			m_dealer.Showfirst();
			m_player.ShowCards();
			winorlose=PlayerPrompt(bet);
			if (m_push == false)
			{
				if (winorlose == false)
				{
					bet *= -1;
					yourstack.Setroll(bet);

				}
				else
				{
					yourstack.Setroll(bet);
				}
			}
			m_dealer.Newhand();
			m_player.Newhand();
			break;
		case 2:
			if (yourstack.Getroll() > 200)
			{
				cout << "Lucky you you won: " << yourstack.Getroll()-200 << endl;
			}
			else
			{
				cout << "Shouldn't have started gambling you lost: "<<200 - yourstack.Getroll() << endl;
			}
			break;
		default:
			cout<< "invalid choice!";
			break;
		}
		

	}
	if (!yourstack.Getroll())
	{
		cout << "Nice Work loser go cry to Your mom!!!" << endl;
	}
}

bool BlackJack::PlayerPrompt(int & bet)
{
	bool bustor21 = false;
	bool dd = false;
	int playerhandvalue = 0;
	int dealerhandvalue = 0;
	int selection = 1;
	int doubledown = 0;
	int split = 0;
	cout << "The value of your cards is:";
	playerhandvalue=m_player.GetValue();
	if (playerhandvalue == 21)
	{
		cout << "You got 21!" << endl;
		bustor21 = true;
	}
	/*if (m_player.Checkforpair())
	{
		cout << "Do you want to split your hand?(1 for yes)";
		cin >> split;
		if (split == 1)
		{

		}

	}*/
	if (playerhandvalue == 10 || playerhandvalue == 11)
	{
		cout << "Nice cards would you like to double down?(1 for yes)";
		cin >> doubledown;
		if (doubledown == 1 && bet <= (yourstack.Getroll() / 2))
		{
			bet += bet;
			dd = true;
			m_player.Deal(m_deck.Deal());
			m_player.ShowCards();
			playerhandvalue = m_player.GetValue();
			if (playerhandvalue == 21)
			{
				cout << "you got 21!" << endl;
				bustor21 = true;
			}
			if (playerhandvalue > 21)
			{
				cout << "You bust!!!" << endl;
			}
			if (bustor21 == false && playerhandvalue < 22)
			{
				m_dealer.ShowCards();
				cout << "Dealers Hand=";
				dealerhandvalue = m_dealer.GetIntialValue();
				while (dealerhandvalue < 17)
				{
					m_dealer.Deal(m_deck.Deal());
					m_dealer.ShowCards();
					cout << "Dealers Hand=";
					dealerhandvalue = m_dealer.GetDealersCurrentValue(dealerhandvalue);
				}
				if (dealerhandvalue<22 && dealerhandvalue>playerhandvalue)
				{
					cout << "Typical BlackJack you LOSE!!!" << endl;
				}
				else if (dealerhandvalue == playerhandvalue)
				{
					m_push = true;
					cout << "Nice work you didn't lose your money but its a TIE!" << endl;
				}
				else
				{
					cout << "Congratulations You win!" << endl;
					bustor21 = true;
				}
			}
		}
		else if (bet > (yourstack.Getroll() / 2) && doubledown == 1)
		{
			cout << "Sorry you don't have enough money to double down" << endl;
			dd = false;
		}
	}
	if (bustor21 == false && dd == false)
	{
			while (playerhandvalue <= 21 && selection == 1 && bustor21 == false)
			{
				cout << "Would you like to hit?(Enter 1 for yes) ";
				cin >> selection;
				if (selection == 1)
				{
					m_player.Deal(m_deck.Deal());
					m_player.ShowCards();
					playerhandvalue = m_player.GetValue();
					if (playerhandvalue == 21)
					{
						cout << "you got 21!" << endl;
						bustor21 = true;
					}
					if (playerhandvalue > 21)
					{
						cout << "You bust!!!" << endl;
					}
				}
		}
		if (bustor21 == false && playerhandvalue<22)
		{
			m_dealer.ShowCards();
			cout << "Dealers Hand=";
			dealerhandvalue = m_dealer.GetIntialValue();
			while (dealerhandvalue < 17)
			{
				m_dealer.Deal(m_deck.Deal());
				m_dealer.ShowCards();
				cout << "Dealers Hand=";
				dealerhandvalue = m_dealer.GetDealersCurrentValue(dealerhandvalue);
			}
			if (dealerhandvalue<22 && dealerhandvalue>playerhandvalue)
			{
				cout << "Typical BlackJack you LOSE!!!" << endl;
			}
			else if (dealerhandvalue == playerhandvalue)
			{
				m_push = true;
				cout << "Nice work you didn't lose your money but its a TIE!" << endl;
			}
			else
			{
				cout << "Congratulations You win!" << endl;
				bustor21 = true;
			}
		}

		
	}
	return bustor21;
}

BlackJack::~BlackJack()
{

}
