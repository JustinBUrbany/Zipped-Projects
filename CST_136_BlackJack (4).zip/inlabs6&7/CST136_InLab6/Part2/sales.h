#ifndef SALES_H
#define SALES_H

class sales
{
public:
	sales();
	void Setarray(double first, double second, double third);
	void displayarray();
	~sales();
private:
	double salesarray[3] = { 0.00,0.00,0.00 };

	
};

#endif
