#include <iostream>
using std::cout;
using std::endl;
#include "pub.h"
#include "book.h"
#include "video.h"

int main()
{
	publication Owner("Justin", 200000.33);
	video coolmovie("Surf's up", 9.99, 113.46);
	Book goodbook("Lord of the Flies", 4.44, 97, 85);
	cout << Owner.gettitle() << ' ' << Owner.getprice() << endl;
	cout << coolmovie.gettitle() << ' ' << coolmovie.getprice() << ' ' << coolmovie.getmins()<<endl;
	cout << goodbook.gettitle() << ' ' << goodbook.getprice() << ' ' << goodbook.getcount() << ' ' << goodbook.getyear()<<endl;
	goodbook.Setarray(120.45, 125.66, 280.12);
	coolmovie.Setarray(1024.01, 2021.97, 1876.45);

	Owner.setprice(15.55);
	Owner.settitle("Randy");
	cout << Owner.gettitle() << ' ' << Owner.getprice() << endl;
	coolmovie.settitle("Titanic");
	coolmovie.setprice(8.88);
	coolmovie.setmins(25.45);
	cout << coolmovie.gettitle() << ' ' << coolmovie.getprice() << ' ' << coolmovie.getmins()<<endl;
	coolmovie.displayarray();

	goodbook.setprice(15.55);
	goodbook.settitle("Randy");
	goodbook.setcount(22);
	goodbook.setyear(84);
	cout << goodbook.gettitle() << ' ' << goodbook.getprice() << ' ' << goodbook.getcount() << ' ' << goodbook.getyear()<<endl;
	goodbook.displayarray();

	return 0;
}