#ifndef VIDEO_H
#define VIDEO_H
#include "pub.h"
#include "sales.h"
class video :public publication, public sales
{
public:
	video(char * title, double price, double mins);
	void setmins(double mins);
	double getmins();
	~video();
private:
	double m_mins=0.00;
};


#endif