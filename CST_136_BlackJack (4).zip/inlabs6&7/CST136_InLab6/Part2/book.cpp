#include "book.h"
#include <iostream>
using std::cout;
using std::endl;
Book::Book(char * title, double price, int count, int year): publication(title, price), m_pgcount(count), m_year(year)
{
	cout << "Book ctor" << endl;
}

void Book::setcount(int count)
{
	m_pgcount = count;
}

void Book::setyear(int year)
{
	m_year = year;
}

int Book::getcount()
{
	return m_pgcount;
}

int Book::getyear()
{
	return m_year;
}

Book::~Book()
{
	cout << "Book dtor" << endl;
}
