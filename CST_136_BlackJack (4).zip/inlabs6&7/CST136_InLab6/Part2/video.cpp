#include "video.h"
#include <iostream>
using std::cout;
using std::endl;
video::video(char * title, double price, double mins): publication(title,price), m_mins(mins)
{
	cout << "vid ctor" << endl;
}

void video::setmins(double mins)
{
	m_mins = mins;
}

double video::getmins()
{
	return m_mins;
}

video::~video()
{
	cout << "vid dtor" << endl;
}
