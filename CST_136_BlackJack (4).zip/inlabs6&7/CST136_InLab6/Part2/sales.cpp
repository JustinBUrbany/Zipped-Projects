#include "sales.h"
#include <iostream>
using std::cout;
using std::endl;



sales::sales()
{
	cout << "sales ctor" << endl;
}

void sales::Setarray(double first, double second, double third)
{
	salesarray[0] = first;
	salesarray[1] = second;
	salesarray[2] = third;
}

void sales::displayarray()
{
	cout << "First month sales: " << salesarray[0] << endl;
	cout << "Second month sales: " << salesarray[1] << endl;
	cout << "Third month sales: " << salesarray[2] << endl;

}

sales::~sales()
{
	cout << "sales dtor" << endl;
}
