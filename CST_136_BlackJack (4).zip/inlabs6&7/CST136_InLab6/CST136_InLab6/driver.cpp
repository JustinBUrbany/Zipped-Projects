#include "base.h"
#include "Derived.h"
#include <iostream>
using std::cout;
using std::cin;
using std::endl;


int main()
{
	Derived obj(1, 2);
	obj.Set(100, 200, 300);
	obj.Show();
	obj.ShowD();

	Base bobj1(1,2,9);
	Base bobj2(3,4);

	cin >> bobj1;
	cin >> bobj2;
	cout << bobj1<<endl;
	cout << bobj2 << endl;
	Base bobj3 = bobj1 + bobj2;
	cout << bobj3;

	return 0;
}