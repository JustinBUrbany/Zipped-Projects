#pragma once
#include "base.h"

class Derived : public Base
{
public:
	Derived(int a = 0, int b = 0);
	void ShowD();
	~Derived();
private:
	int ds = 0;
	int dt = 0;

};