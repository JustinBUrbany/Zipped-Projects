#include "base.h"
#include <iostream>
using std::cout;
using std::cin;
using std::endl;

Base::Base(int a, int b, int c):ba(a), bb(b), bc(c)
{
	cout << "Base Ctor" << endl;
}

void Base::Set(int a, int b, int c)
{
	ba = a;
	bb = b;
	bc = c;

}

void Base::Show()
{
	cout << ba << endl;
	cout << bb << endl;
	cout << bc << endl;

}

Base & Base::operator=(Base & rhs)
{
	this->ba = rhs.ba;
	this->bb = rhs.bb;
	this->bc = rhs.bc;

	return *this;
}

Base & Base::operator+(Base & rhs)
{
	this->ba += rhs.ba;
	this->bb += rhs.bb;
	this->bc += rhs.bc;

	return *this;
}

istream & operator >>(istream & is, Base & rhs)
{
	is >> rhs.ba;
	is >> rhs.bb;
	is >> rhs.bc;

	return is;
}
ostream & operator <<(ostream & os, Base & rhs)
{
	os << rhs.ba << rhs.bb << rhs.bc;

	return os;
}

Base::~Base()
{
	cout << "Base Dtor" << endl;
}
