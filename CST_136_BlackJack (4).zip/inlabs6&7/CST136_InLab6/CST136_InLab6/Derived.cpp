#include "Derived.h"
#include <iostream>
using std::cout;
using std::cin;
using std::endl;

Derived::Derived(int a, int b): ds(a), dt(b)
{
	cout << "Derived Ctor" << endl;
}

void Derived::ShowD()
{
	cout << ds << endl;
	cout << dt << endl;
	Show();
}

Derived::~Derived()
{
	cout << "Derived Dtor" << endl;
}
