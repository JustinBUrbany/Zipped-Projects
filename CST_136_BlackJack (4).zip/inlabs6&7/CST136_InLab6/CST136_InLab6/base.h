
//#include <istream>
//#include <ostream>
//using std::istream;
//using std::ostream;
#ifndef BASE_H
#define BASE_H
#include <istream>
#include <ostream>
using std::istream;
using std::ostream;
class Base {
	friend istream & operator >>(istream & is, Base & rhs);
	friend ostream & operator <<(ostream & os, Base & rhs);
public:
	Base(int a=0, int b=0, int c=0);
	void Set(int a=0, int b=0, int c=0);
	void Show();
	Base & operator =(Base & rhs);
	Base & operator +(Base & rhs);
	~Base();

private:
	int ba=0;
	int bb=0;
	int bc=0;

};

#endif