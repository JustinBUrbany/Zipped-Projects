// File car.cpp

#include <iostream>
#include "car.h"

void Car::identify() const
{
	cout << "I am a car\n";
}

Car::~Car()
{
	cout << "Car destructor\n";
}
