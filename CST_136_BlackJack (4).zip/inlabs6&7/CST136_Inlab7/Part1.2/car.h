// Just some sample code illustrating another point - you will recognize this
// from our class discussion.
// Make sure you check this out in the debugger AFTER you
// get it setup.
// InLab8Part2.cpp 
// Code originally from Nagler - and does a great job illustrating a point!
// NOTE:  I would urge you to NOT sell Nagler at the end of the term!

// File car.h
#include <iostream>
using std::cout;
using std::endl;

#ifndef CAR_H
#define CAR_H

class Car 
{
public:
	virtual void identify() const=0;
	void tester() { cout << "INSIDE CAR - TESTER NON virtual function" << endl; }
	virtual void virtTester() { cout << "INSIDE CAR-VIRTUAL FUNCTION" << endl; }
	virtual ~Car();
};

#endif

