// File toyota.cpp

#include <iostream>
#include "toyota.h"

void Toyota::identify() const
{
	cout << "I am a Toyota\n";
}

Toyota::~Toyota()
{
	cout << "Toyota destructor\n";
}

