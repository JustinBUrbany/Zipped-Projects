
// File main.cpp

#include "ford.h"
#include "toyota.h"

int main()
{
	Car* inventory[] =
	{ new Ford, new Ford, new Toyota };
	Ford f1;
	f1.identify();
	const int size = sizeof(inventory) /     // BEST MAKE SENSE   
		sizeof(*inventory);
	for (int i = 0; i < size; ++i)
	{
		inventory[i]->identify();		// WATCH THIS - CHECK OUT THE VPTR & VTABLE!
		delete inventory[i];
	}
	return 0;
}

/* The output of this program is:

I am a car
Car destructor
I am a Ford
Car destructor
I am a Toyota
Car destructor
*/