// File ford.h

#ifndef FORD_H
#define FORD_H

#include "car.h"

class Ford : public Car
{
public:
	virtual  void identify() const;
	~Ford();
};

#endif

