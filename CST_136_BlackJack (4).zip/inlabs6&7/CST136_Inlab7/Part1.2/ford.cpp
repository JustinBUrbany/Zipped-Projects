// File ford.cpp

#include <iostream>
#include "ford.h"

void Ford::identify() const
{
	cout << "I am a Ford\n";
}

Ford::~Ford()
{
	cout << "Ford destructor\n";
}
