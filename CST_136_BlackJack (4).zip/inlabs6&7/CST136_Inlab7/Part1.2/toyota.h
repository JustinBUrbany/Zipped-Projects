// File toyota.h

#ifndef TOYOTA_H
#define TOYOTA_H

#include "car.h"

class Toyota : public Car
{
public:
	virtual  void identify() const;
	~Toyota();
};

#endif