#ifndef PUB_H
#define PUB_H


class publication
{
public:
	publication();
	publication(char* title, double price = 0.00);
	void settitle(char * title);
	void setprice(double price);
	virtual void PubData();
	virtual ~publication();
private:
	char * m_title = nullptr;
	double m_retprice = 0.00;
};



#endif // !PUB_H