#include "pub.h"
//#include "sales.h"
#ifndef BOOK_H
#define BOOK_H

class Book : public publication//, public sales
{
public:
	Book(char * title, double price, int count, int year);
	void setcount(int count);
	void setyear(int year);
	virtual void PubData();
	virtual ~Book();
private:
	int m_pgcount = 0;
	int m_year = 0;
};


#endif