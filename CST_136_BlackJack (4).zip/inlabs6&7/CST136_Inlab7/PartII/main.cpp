#define _CRTDBG_MAP_ALLOC
#include <iostream>
#include "pub.h"
#include "book.h"
#include "video.h"
#include <crtdbg.h>	
using std::cout;
using std::endl;

int main()
{
	_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
	publication * bunchofpubs[] = { new publication("Crumy instruction", 1.11), new publication("really not fun", 2.22), new Book("Boring",6.66,100,1992), new video("@#1", 67.73, 122.22)};
	for (int i = 0; i < 4; i++)
	{
		bunchofpubs[i]->PubData();
		cout << endl;
	}


	for (int i = 0; i < 4; i++)
	{
		delete bunchofpubs[i];
			bunchofpubs[i] = nullptr;
	}
	//char * temp = new char[10];
	return 0;
}