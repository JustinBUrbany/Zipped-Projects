#include "video.h"
#include <iostream>
using std::cout;
using std::endl;
video::video(char * title, double price, double mins) : publication(title, price), m_mins(mins)
{
	cout << "vid ctor" << endl;
}

void video::setmins(double mins)
{
	m_mins = mins;
}

video::~video()
{
	cout << "vid dtor" << endl;
}

void video::PubData()
{
	publication::PubData();
	cout << " Movie Length Mins: " << m_mins << endl;
}
