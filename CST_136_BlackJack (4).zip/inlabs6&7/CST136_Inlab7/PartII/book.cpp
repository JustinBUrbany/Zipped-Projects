#include "book.h"
#include <iostream>
using std::cout;
using std::endl;
Book::Book(char * title, double price, int count, int year) : publication(title, price), m_pgcount(count), m_year(year)
{
	cout << "Book ctor" << endl;
}

void Book::setcount(int count)
{
	m_pgcount = count;
}
void Book::setyear(int year)
{
	m_year = year;
}
void Book::PubData()
{
	publication::PubData();
	cout << " Page count " << m_pgcount << " Year: " << m_year << endl;
}


Book::~Book()
{
	cout << "Book dtor" << endl;
}

