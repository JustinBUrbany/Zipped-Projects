#include "pub.h"
#include <iostream>
using std::cout;
using std::endl;
publication::publication()
{
}

publication::publication(char * title, double price) : m_title(title), m_retprice(price)
{
	cout << "Pub ctor" << endl;
}

void publication::settitle(char * title)
{
	m_title = title;
}

void publication::setprice(double price)
{
	m_retprice = price;
}

void publication::PubData()
{
	cout << "Title " << m_title << " price " << m_retprice<<' ';
}

publication::~publication()
{
	//delete[]m_title;
	cout << "Pub Dtor" << endl;
}
