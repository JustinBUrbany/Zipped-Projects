// Just some sample code for discussion
// InLab8Part1.cpp 
// Code originally from Nagler - and does a great job illustrating a point!
// File mystring.h

#ifndef MYSTRING_H
#define MYSTRING_H

#include <iostream> // HEY  - UPDATE THIS OK!
#include <string.h>
#include <ostream>
using std::ostream;
using std::cout;
using std::endl;

class String
{
	friend inline ostream& operator<< (ostream&, const String&);
public:
	inline String(const char* = "");
	inline String(const String&);
	~String() { delete[] ptr; cout << "string dtor" << endl; }
	inline String& operator= (const String&);
protected:
	char* ptr;
};

inline ostream& operator<< (ostream& str, const String& s)
{
	const char quote = '"';
	return str << quote << s.ptr << quote;
}

inline String::String(const char* p) : ptr(0)
{
	p = p ? p : "";
	ptr = new char[strlen(p) + 1];
	strcpy(ptr, p);
}

inline String::String(const String& s) : ptr(0)
{
	cout << "string copy ctor" << endl;
	ptr = new char[strlen(s.ptr) + 1];
	strcpy(ptr, s.ptr);
}

inline String& String::operator= (const String& s)
{
	cout << "string op=" << endl;
	if (this != &s)
	{
		unsigned length = strlen(s.ptr);
		if (strlen(ptr) != length)
		{
			delete[] ptr;
			ptr = new char[length + 1];
		}
		strcpy(ptr, s.ptr);
	}
	return *this;
}

#endif