// File dstring.h

#ifndef DSTRING_H
#define DSTRING_H

#include <iostream>
#include "string.h"
#include <ostream>
using std::endl;
using std::ostream;

class DString : public String
{
	friend inline ostream& operator << (ostream&, const DString&);
public:
	DString() : String(), length(strlen(ptr)) { cout << "dstring ctor" << endl; }
	DString(const char* p) : String(p), length(strlen(ptr)) {}
	DString(const DString& d) : String(d), length(d.length) {}
	~DString() {
		cout << "dstring dtor" << endl;
	}
	inline DString& operator= (const DString&);
private:
	unsigned length;
};

inline ostream& operator<< (ostream& str, const DString& d)
{
	return str << static_cast<const String&>(d)
	<< " length = " << d.length;
}

inline DString& DString::operator=(const DString& d)
{
	if (this != &d)
	{
		String::operator=(d);
		length = d.length;
	}
	return *this;
}

#endif
