// File main.cpp

#include <iostream>
using std::cout;
#include "dstring.h"

int main()
{
	DString n1;
	DString n2("C++ test string");
	DString n3(n2);
	DString n4;
	n4 = "A different string";
	cout << n1 << '\n';
	cout << n2 << '\n';
	cout << n3 << '\n';
	cout << n4 << '\n';
	return 0;
}

/* A typical run would yield:

"" length = 0
"C++ test string" length = 15
"C++ test string" length = 15
"A different string" length = 18

*/
