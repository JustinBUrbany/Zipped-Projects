//Justin Urbany
//Lab3.c

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct itemlist
{
  char *  m_item;
  int  m_placement;
  struct itemlist *m_next;
  struct itemlist *m_prev;
}itemlist_t;

//void DisplayList(itemlist_t * head);
//void Delete(itemlist_t * head);

int main(int argc, char * argv[])
{
  FILE *  f=fopen(argv[1],"r");
  itemlist_t * head=NULL;
  itemlist_t * travel=NULL;
  itemlist_t * current=NULL;
  itemlist_t * trail=NULL;
  int next=0;
  char buffer[100];

  // f.fopen(]);

  while(fgets(buffer,100,f)!=NULL)
  {
    if(0==next)
    {
      head=(itemlist_t*) malloc (sizeof(itemlist_t));
      head->m_item=strdup(buffer);
      head->m_placement=next+1;
      head->m_prev=NULL;
      head->m_next=NULL;
      travel=head;
    }
    else
    {
      travel->m_next=(itemlist_t*) malloc(sizeof(itemlist_t));
      travel->m_next->m_prev=travel;
      travel=travel->m_next;
      travel->m_item=strdup(buffer);
      travel->m_placement=next+1;
    }

    next++;
  }

  //DisplayList(head);
  //Delete(head);

  // itemlist_t * current=head;
  current=head;
    while(NULL !=current)
    {
      printf("The %denst element: is %s",current->m_placement,current->m_item);
      current=current->m_next;
    }
  current=head;
  //  itemlist_t * trail=NULL;
  while(NULL != current)
  {
    trail=current->m_next;
    free(current->m_item);
    free(current);
    current=trail;
  }
  head=NULL;
  travel=NULL;
  trail=NULL;
  current=NULL;

  fclose(f);

  return 0;
}

//void DisplayList(itemlist_t *head)
//{
// itemlist_t * travel=head;
// while(travel != NULL)
// {
//   printf("The %dst element: is %s",travel->m_placement,travel->m_item);
//   travel=travel->m_next;
// }
//
//}


//void Delete(itemlist_t * head)
//{
// itemlist_t * current=head;
// itemlist_t * next=NULL;
// while(current != NULL)
// {
//   next=current->m_next;
//   free(current->m_item);
///   free(current);
//  current=next;
// }
// head=NULL;
//
//}
