
#
# B Justin Urbany
#
import sys
thefile = sys.argv[1]
f = open(thefile,'r')
filestring=f.read()
filestring="".join(filestring.split())
i=int(sys.argv[2])

if(len(sys.argv)<3):
    print "Not enough ARGUEMNTS"
    exit()
biggestvalue=0
location=0

if(i>len(filestring)):
    print "Can't add that many digitis"
    exit()

for a in range(0,len(filestring)-i):
    string=filestring[a:a+i]
    value=0
    for b in string:
        value+=int(b,16) #cast string characters to hex
        if(value>biggestvalue):
            biggestvalue=value
            location=string

print biggestvalue, location
#print location
#temp=0
#for z in filestring[:i]:
 #   temp=(int(z)+temp
  #  print temp

#print filestring[:i]    
