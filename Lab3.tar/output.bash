#!/bin/bash

#Justin Urbany February 1st
show_help()
{
echo " place -o followed by jesse  output file and -i followed by yours mine or whatever tester outputfile"
exit
}

jesseoutputfile="good"
myoutputfile="bad"
nocommands=0
condition=0

while getopts "ho:i:" OPT
do
case "${OPT}" in
    h)
      show_help
      ;;
    o)
      jesseoutputfile=${OPTARG}
      nocommands=1
      ;;
    i)
      myoutputfile=${OPTARG}
      nocommands=1
      ;;
esac
done

if [ $nocommands -eq 0 ]
then
    show_help
fi

result=$(diff -y -W 72 $jesseoutputfile $myoutputfile)

if [ $jesseoutputfile = $myoutputfile ]
    then
    echo "THEY ARE THE SAME!!!!!!!!!"
else
    echo "THEY'RE DIFFERERRERNT"
    echo "$result"
fi
