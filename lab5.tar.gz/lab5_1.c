#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "file_struct.h"
#include "file_index.h"

typedef struct id_linklist_s{
    file_index_t data;
    struct id_linklist_s * m_next;
}id_linklist_t;

void show_help(void);
void InsertOrdered(char string[10], id_linklist_t ** myll,int count);
void Purge(id_linklist_t * myll);
//char * WriteString(char string[INDEX_ID_LEN], int size);


int main(int argc, char * argv[])
{
    id_linklist_t *  idllhead=NULL;
    id_linklist_t *  travel=NULL;
    bin_file_t BinIn;
    int readin=STDIN_FILENO;
    int writeout=STDOUT_FILENO;
    ssize_t bytes_read=-1;
    int opt;
    int verbose=0;
    int flags={ O_WRONLY | O_CREAT | O_TRUNC};
    mode_t mode={S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH};
    int count=0;
//    char teststring[]={"1213234"};
    // char * tempstring;

    while((opt=getopt(argc,argv,"i:o:hv"))!=-1)
    {
        switch(opt)
        {
        case 'h':
            show_help();
            break;
        case 'v':
            verbose=1;
            break;
        case 'i':
            readin=open(optarg,O_RDONLY,mode);
            break;
        case 'o':
            writeout=open(optarg,flags,mode);
            break;
        }
    }
    idllhead=NULL;
    while((bytes_read=read(readin,&BinIn,sizeof(BinIn)))>0)
    {
        // tempstring = WriteString(BinIn.id,sizeof(BinIn.id));
//        printf("tempstring is %s\n",tempstring);
        //      char id[ID_LEN] = {};
        // strncpy(id, strtok(BinIn.id, " "), ID_LEN);
        // printf(id);
        InsertOrdered(BinIn.id,&idllhead,count);
        printf("Reading file #%d passed in was \n",count);
        count++;
    }
 
    travel=idllhead;
    count=0;
    while((travel!=NULL))
    {
        write(writeout, &travel->data ,sizeof(travel->data));//sizeof(travel->id));
        //write(writeout,travel->data.offset ,sizeof(travel->data.offset));
         printf("Wrote %s and %d on this pass\n",travel->data.id,(int)travel->data.offset);
        travel=travel->m_next;
        if(verbose==1 && travel==NULL)
        {
            fprintf(stderr,"Wrote the new Struct to the file");
        }
    }
    Purge(idllhead);
    return 0;
}

void show_help(void)
{
    printf("-i if you want to give input file to program\n");
    printf("-o if you want to give output file to prgram\n");
    printf("-h to show help and quit\n");
    printf("-v to go into verbose mode\n");
    exit(1);
}
void InsertOrdered(char string[INDEX_ID_LEN], id_linklist_t **  myll, int count)
{
    id_linklist_t * nn=(id_linklist_t*)malloc(sizeof(id_linklist_t));
    id_linklist_t * travel=*myll;
    id_linklist_t * trail=NULL;
    strncpy(nn->data.id,string,ID_LEN);
    nn->data.offset=(count*(sizeof(bin_file_t)));
    nn->m_next=NULL;
    printf("New Nodes String is %s", nn->data.id);
    printf("checkspaces");
    // printf(" offset is %d",(int)nn->offset);
    
    if(travel!=NULL)
    {
        // printf("Travel was not equal to NULL\n");
       while(travel != NULL && strncmp(nn->data.id,travel->data.id,INDEX_ID_LEN)>0)
        {
         trail=travel;
         travel=travel->m_next;
        }
        if(travel == NULL)
        {
            printf("Adding to the End");
            trail->m_next=nn;
            nn->m_next=travel;
        }
        else if(trail==NULL)
        {
            printf("Adding to the front");
            nn->m_next=*myll;
           *myll=nn;
        }
        else
        {
            printf("Adding somewhere in middle");
            trail->m_next=nn;
            nn->m_next=travel;
        }
    }
    else
    {
        printf("Intializing Head ");
        nn->m_next=NULL;
        *myll=nn;
        printf("%s\n",(*myll)->data.id);
    }
    printf("\n");
}

void Purge(id_linklist_t * myll)
{
    id_linklist_t * travel = myll;
    while(myll!=NULL)
    {
        myll=myll->m_next;
        free(travel);
        travel=myll;
    }
}

/*char *  WriteString(char string[INDEX_ID_LEN], int size)
{
    char buffy[INDEX_ID_LEN];
    int ii=-1;
    memcpy(buffy, string, size);
//    for (ii=(size-1); ii>10; ii--)
    //  {
    //   buffy[ii]='\0';
    //  }
    //  printf("Buffy is %s\n",buffy);
    //  strcpy(string, buffy);
    return string;
    }*/
