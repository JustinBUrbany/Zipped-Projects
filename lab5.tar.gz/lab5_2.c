#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "file_struct.h"
#include "file_index.h"




void show_help(void);
void Search_Display(char ss[20], int readfile, int writefile);
void Search_Display_WI(char ss[20],int indexfile, int readfile, int writefile);
void WriteFile(char* string, int size,int file);


int main(int argc, char * argv[])
{
    int opt;
    int j=-1;
    off_t offset;
    int verbose=0;
    int readindata=STDIN_FILENO;
    int readinIndex=-1;
    int writeout=STDOUT_FILENO;
    int flags = { O_WRONLY | O_CREAT | O_TRUNC};
    mode_t mode = { S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH};
    char string[20]={'\0'};
    
    while((opt=getopt(argc,argv,"I:i:o:hv")) !=-1)
    {
        switch(opt)
        {
        case 'h':
            show_help();
            break;
        case 'v':
            verbose=1;
            break;
        case 'i':
            readindata=open(optarg, O_RDONLY, mode);
            break;
        case 'o':
            writeout=open(optarg,flags,mode);
            break;
        case 'I':
            readinIndex=open(optarg, O_RDONLY, mode);
            break;
        default:
            show_help();
            break;
        }
    }
    
    if(optind<argc)
    {
        for(j=optind; j<argc; j++)
        {
            strcpy(string,argv[j]);
            if(readinIndex==-1)
            {
                Search_Display(string,readindata,writeout);
                offset=lseek(readindata,0,SEEK_CUR);
                offset=lseek(readindata,-offset, SEEK_CUR);
            }
            else
            {
                Search_Display_WI(string,readinIndex, readindata, writeout);
                offset=lseek(readinIndex,0,SEEK_CUR);
                offset=lseek(readinIndex,-offset, SEEK_CUR);
                offset=lseek(readindata,0,SEEK_CUR);
                offset=lseek(readindata,-offset, SEEK_CUR);
            }
        }
    }
    else
    {
        printf("You didn't add any id numbers to serach for \n");
        if(verbose==1)
        {
            fprintf(stderr,"Nothing was passed to search for");
        }
    }
    return 0;
}

void show_help(void)
{
    printf("-h is Help and shows all command line options and what they do\n");
    printf("-v is verbose mode and will print extra output to stderr\n");
    printf("-I is the name of the Index file use to search the data file\n");
    printf("-i is the name of the binary data file you will search");
    printf("-o is the output file you write to\n");
    printf("As well as the other arguements inorder to use this program id numbers must be passed to search for\n");
}

void Search_Display(char ss[20], int readfile, int writefile)
{
    ssize_t bytes_read=-1;
    bin_file_t BinIn;
    int search=0;
    while(search==0 && (bytes_read=read(readfile,&BinIn,sizeof(BinIn)))>0)
    {
        if(strncmp(BinIn.id,ss,strlen(ss))==0)
        {
            search=1;

            write(writefile,"id: ", 4);
            WriteFile(BinIn.id,sizeof(BinIn.id),writefile);
            write(writefile,"\n", 2);

            write(writefile, "first_name: ",12);
            WriteFile(BinIn.fname,sizeof(BinIn.fname),writefile);
            write(writefile,"\n", 2);

            write(writefile, "middle_name: ", 13);
            WriteFile(BinIn.mname,sizeof(BinIn.mname),writefile);
            write(writefile,"\n", 2);

            write(writefile, "last_name: ", 11);
            WriteFile(BinIn.lname,sizeof(BinIn.lname),writefile);
            write(writefile,"\n", 2);

            write(writefile, "street: ", 8);
            WriteFile(BinIn.street,sizeof(BinIn.street),writefile);
            write(writefile,"\n", 2);

            write(writefile, "city: ", 6);
            WriteFile(BinIn.city,sizeof(BinIn.city),writefile);
            write(writefile,"\n", 2);

            write(writefile, "zip: ", 5);
            WriteFile(BinIn.zip,sizeof(BinIn.zip),writefile);
            write(writefile,"\n", 2);

            write(writefile, "country: ", 9);
            WriteFile(BinIn.country_code,sizeof(BinIn.country_code),writefile);
            write(writefile,"\n", 2);

            write(writefile, "email: ", 7);
            WriteFile(BinIn.email,sizeof(BinIn.email),writefile);
            write(writefile,"\n", 2);

            write(writefile, "phone: ", 7);
            WriteFile(BinIn.phone,sizeof(BinIn.phone),writefile);

        }
    }
    if(search==0)
    {
        printf("The id you were looking for was never found\n");
    }
}

void Search_Display_WI(char ss[20],int indexfile, int readfile, int writefile)
{
    ssize_t bytes_read=0;
    off_t offset;
    int search=0;
    file_index_t searchfile;
    bin_file_t BinIn;
    while(search==0 && (bytes_read=read(indexfile,&searchfile,sizeof(searchfile))))
    {
        if(strncmp(ss,searchfile.id,strlen(ss))==0)
        {
            search=1;
            offset=searchfile.offset;
        }
    }
    if(search==1)
    {
         lseek(readfile,offset,SEEK_CUR);
         read(readfile, &BinIn,sizeof(BinIn));

         write(writefile,"id: ", 4);
         WriteFile(BinIn.id,sizeof(BinIn.id),writefile);
         write(writefile,"\n", 2);

         write(writefile, "first_name: ",12);
         WriteFile(BinIn.fname,sizeof(BinIn.fname),writefile);
         write(writefile,"\n", 2);

         write(writefile, "middle_name: ", 13);
         WriteFile(BinIn.mname,sizeof(BinIn.mname),writefile);
         write(writefile,"\n", 2);

         write(writefile, "last_name: ", 11);
         WriteFile(BinIn.lname,sizeof(BinIn.lname),writefile);
         write(writefile,"\n", 2);

         write(writefile, "street: ", 8);
         WriteFile(BinIn.street,sizeof(BinIn.street),writefile);
         write(writefile,"\n", 2);

         write(writefile, "city: ", 6);
         WriteFile(BinIn.city,sizeof(BinIn.city),writefile);
         write(writefile,"\n", 2);

         write(writefile, "zip: ", 5);
         WriteFile(BinIn.zip,sizeof(BinIn.zip),writefile);
         write(writefile,"\n", 2);

         write(writefile, "country: ", 9);
         WriteFile(BinIn.country_code,sizeof(BinIn.country_code),writefile);
         write(writefile,"\n", 2);

         write(writefile, "email: ", 7);
         WriteFile(BinIn.email,sizeof(BinIn.email),writefile);
         write(writefile,"\n", 2);

         write(writefile, "phone: ", 7);
         WriteFile(BinIn.phone,sizeof(BinIn.phone),writefile);

    }
    else
    {
        printf("The id you were looking for was never found\n");
    }
    

}


void WriteFile(char* string, int size,int file)
{

    char buffy[100] = {'\0'};
    int ii = -1;

    memcpy(buffy, string, size);
    for (ii = (size - 1); ii > 0 && buffy[ii] == ' '; ii--) {
        buffy[ii] = '\0';
    }
    write(file,buffy,strlen(buffy));
}
