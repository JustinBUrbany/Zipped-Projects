//Justin Urbany
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "file_struct.h"

void show_help(void);
void WriteFile(char* string, int size,int file);



int main(int argc, char * argv[])
{
  bin_file_t   BinIn;
  int flags={ O_WRONLY | O_CREAT | O_TRUNC};
  mode_t mode={S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH};
  int fd=STDIN_FILENO;
  int B=STDOUT_FILENO;
  ssize_t bytes_read=-1;
  int opt;
  int verbose=0;

  while((opt=getopt(argc,argv,"i:o:hv")) !=-1)
  {
      switch(opt)
      {
      case 'h':
          show_help();
          break;
      case 'v':
          verbose=1;
          break;
      case 'i':
          fd=open(optarg,flags,mode);
          break;
      case 'o':
          B=open(optarg, flags,mode);
          break;
      default:
          break;
      }
  }
  if(verbose)
      {
          fprintf(stderr,"About to read struct");
      }
 memset(&BinIn, 0, sizeof(BinIn));
  write(B,"id,first_name,middle_name,last_name,street,city,zip,country,email,phone\n",strlen("id,first_name,middle_name,last_name,street,city,zip,country,email,phone\n"));


  while((bytes_read=read(fd,&BinIn,sizeof(BinIn)))>0)
    {
       
     //      BinIn.id[sizeof(BinIn.id)-1]='\0';

        WriteFile(BinIn.id,sizeof(BinIn.id),B);
        write(B,",",1);

/*      for(i=(sizeof(BinIn.id)-1); i>0 && BinIn.id[i] == ' '; i--)
	{
	  BinIn.id[i]='\0';
	}
      BinIn.id[i+1]=',';
      write(B,BinIn.id,strlen(BinIn.id));*/

      //BinIn.fname[sizeof(BinIn.fname)-1]='\0';
        WriteFile(BinIn.fname,sizeof(BinIn.fname),B);
        write(B,",",1);

/*      for(i=(sizeof(BinIn.fname)-1); i>0 && BinIn.fname[i] == ' '; i--)
        {
          BinIn.fname[i]='\0';
        }
      BinIn.fname[i+1]=',';
      write(B,BinIn.fname,strlen(BinIn.fname));

      //BinIn.mname[sizeof(BinIn.mname)-1]='\0';
      WriteFile(BinIn.mname,sizeof(BinIn.mname));*/
        WriteFile(BinIn.mname,sizeof(BinIn.mname),B); 
        write(B,",",1);
   
/* for(i=(sizeof(BinIn.mname)-1); i>0 && BinIn.mname[i] == ' '; i--)
        {
          BinIn.mname[i]='\0';
        }
       BinIn.mname[i+1]=',';
      write(B,BinIn.mname,strlen(BinIn.mname));*/

        WriteFile(BinIn.lname,sizeof(BinIn.lname),B);
        write(B,",",1);


      //BinIn.lname[sizeof(BinIn.lname)-1]='\0';
      /* for(i=(sizeof(BinIn.lname)-1); i>0 && BinIn.lname[i] == ' '; i--)
        {
          BinIn.lname[i]='\0';
        }
       BinIn.lname[i+1]=',';
       write(B,BinIn.lname,strlen(BinIn.lname));*/

      // BinIn.street[sizeof(BinIn.street)-1]='\0';
        WriteFile(BinIn.street,sizeof(BinIn.street),B);
        write(B,",",1);
     
      /*for(i=(sizeof(BinIn.street)-1); i>0 && BinIn.street[i] == ' '; i--)
        {
          BinIn.street[i]='\0';
        }
      BinIn.street[i+1]=',';
      write(B,BinIn.street,strlen(BinIn.street));*/

      // BinIn.city[sizeof(BinIn.city)-1]='\0';

      /*  {
          char buffy[100] = {'\0'};
          int ii = -1;
	
          memcpy(buffy, BinIn.city, sizeof(BinIn.city));
          for (ii = sizeof(BinIn.city) - 1; ii > 0 && buffy[ii] == ' '; ii--) {
              buffy[ii] = '\0';
          }
          printf(">>>%s<<<\n", buffy);
      }*/
        WriteFile(BinIn.city,sizeof(BinIn.city),B);
        write(B,",",1);

      /* for(i=(sizeof(BinIn.city)-1); i>0 && BinIn.city[i] == ' '; i--) 
	{
	  BinIn.city[i]='\0';
	}
      if(strlen(BinIn.city)>=sizeof(BinIn.city))
	{
	  BinIn.city[i-1]=',';
	  BinIn.city[i]='\0';
	}
      else
	{
	  BinIn.city[i+1]=',';
	}
      write(B,BinIn.city,strlen(BinIn.city));*/
     
      //BinIn.zip[sizeof(BinIn.zip)-1]='\0';
        WriteFile(BinIn.zip,sizeof(BinIn.zip),B);
        write(B,",",1);
     
 //  for(i=(sizeof(BinIn.zip)-1); i>0 && BinIn.zip[i] == ' '; i--)
          //    {
            //  BinIn.zip[i]='\0';
          // }
      //    if(strlen(BinIn.zip)>=sizeof(BinIn.zip))
//	{
//	  BinIn.zip[i-1]=',';
      //        BinIn.zip[i]='\0';
//	}
      //     else
//	{
        //    BinIn.zip[i+1]=',';
//	}
      // write(B,BinIn.zip,strlen(BinIn.zip));
     	
      //  BinIn.country_code[sizeof(BinIn.country_code)-1]='\0';
        WriteFile(BinIn.country_code,sizeof(BinIn.country_code),B);
        write(B,",",1);

//      for(i=(sizeof(BinIn.country_code)-1); i>0 && BinIn.country_code[i] == ' '; i--)
      //      {
      //  BinIn.country_code[i]='\0';
      // }
      //	BinIn.country_code[i+1]=',';
//	write(B,BinIn.country_code,strlen(BinIn.country_code));

	//BinIn.email[sizeof(BinIn.email)-1]='\0';
        WriteFile(BinIn.email,sizeof(BinIn.email),B);
        write(B,",",1);
//	for(i=(sizeof(BinIn.email)-1); i>0 && BinIn.email[i] == ' '; i--)
    // {
            //        BinIn.email[i]='\0';
    //  }
	//	BinIn.email[i]='\0';
    //  BinIn.email[i+1]=',';
    // write(B,BinIn.email,strlen(BinIn.email));

      // BinIn.phone[sizeof(BinIn.phone)-1]='\0';
 
        WriteFile(BinIn.phone,sizeof(BinIn.phone),B);
 
        if(verbose)
           fprintf(stderr,"wrote to file");

    }

   return 0;
}
  


void show_help(void)
  {
      printf("if command line arguement -h: shows help and exits program\n");
      printf("if -v goes into verbose mode and gives analysis to stderror\n");
      printf("if -i then must give the file to input from stdin\n");
      printf("if -o then must provide an outputfile wiht stdout\n");
      exit(0);
  }


void WriteFile(char* string, int size,int file)
{
    
    char buffy[100] = {'\0'};
    int ii = -1;

    memcpy(buffy, string, size);
    for (ii = (size - 1); ii > 0 && buffy[ii] == ' '; ii--) {
        buffy[ii] = '\0';
    }
    write(file,buffy,strlen(buffy));
}



