#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "file_struct.h"
#define SIZE 1000

void show_help(void);

int main(int argc, char * argv[])
{
  bin_file_t * BinOut;
  int firstlinecheck =0;
  char buffer[SIZE]={'\0'};
  char * partialstring;
  int flags={ 
             O_RDWR |
             O_CREAT |
             O_TRUNC
            };
  mode_t mode=(
	       S_IRUSR
	       | S_IWUSR
	       | S_IRGRP
	       | S_IWGRP
	       | S_IROTH
	       );
  FILE * f;
  int  B=-1;
  int opt;
  int verbose=0;
  int inputi=0;
  int inputo=0;
  while((opt=getopt(argc,argv,"i:o:hv")) !=-1)
  {
      switch(opt)
      {
      case 'h':
          show_help();
          break;
      case 'v':
          verbose=1;
          break;
      case 'i':
          inputi=1;
          f=fopen(optarg,"r");
          break;
      case 'o':
          B=open(optarg, flags,mode);
          inputo=1;
          break;
      default:
          break;
      }
  }
  
      if(inputi==0)
      {
          f=stdin;
      }
      if(inputo==0)
      {
          B=STDOUT_FILENO;
      }
      if(verbose)
      {
          fprintf(stderr, "About to open File");
      }
  while(fgets(buffer,SIZE,f)!=NULL)
  {
    partialstring=NULL;
    if(0==firstlinecheck)
    {
      firstlinecheck++;
      if(verbose)
      {
          fprintf(stderr, "Skipping the first line");
      }
    }
    else
    { 

     BinOut=(bin_file_t*)malloc(sizeof(bin_file_t));

     memset(BinOut,' ', sizeof(bin_file_t));
     partialstring = strtok(buffer,",");
     memcpy( BinOut->id,partialstring,strlen(partialstring));
     
       
     // printf("%s",partialstring);
       
     partialstring=strtok(NULL,",");
     memcpy(BinOut->fname,partialstring,strlen(partialstring));
     
       
     // printf("%s",partialstring);
       
     partialstring=strtok(NULL,",");
     memcpy(BinOut->mname,partialstring,strlen(partialstring));
     
       
     // printf("%s",partialstring);
       
     partialstring=strtok(NULL,",");
     memcpy(BinOut->lname,partialstring,strlen(partialstring));
     
       
     // printf("%s",partialstring);
       
     partialstring=strtok(NULL,",");
     memcpy(BinOut->street,partialstring, strlen(partialstring));
     
       
     // printf("%s",partialstring);
       
     partialstring=strtok(NULL,",");
     memcpy(BinOut->city,partialstring, strlen(partialstring));
     
       
     // printf("%s",partialstring);
       
     partialstring=strtok(NULL,",");
     memcpy(BinOut->zip,partialstring,strlen(partialstring));
     
      
     // printf("%s",partialstring);

     partialstring=strtok(NULL,",");
     memcpy(BinOut->country_code, partialstring, strlen(partialstring));
    
       
     // printf("%s",partialstring);
       
     partialstring=strtok(NULL,",");
     memcpy(BinOut->email, partialstring, strlen(partialstring));
     
    
     // printf("%s",partialstring);
       
     partialstring=strtok(NULL, ",");
     memcpy(BinOut->phone, partialstring, strlen(partialstring));
     
       
     // printf("%s\n", partialstring);
       
     write(B,BinOut, sizeof(bin_file_t));

     free(BinOut);
    
    }
  }
  fclose(f);
  close(B);
  if(verbose)
  {
  fprintf(stderr, "Files Are closed");
  }
  return 0;
}


  void show_help(void)
  {
      printf("if command line arguement -h: shows help and exits program\n");
      printf("if -v goes into verbose mode and gives analysis to stderror\n");
      printf("if -i then must give the file to input from stdin\n");
      printf("if -o then must provide an outputfile wiht stdout\n");
      exit(0);
  }
