// CST-240
// Winter 2017
// R. Jesse Chaney
// 

#ifndef _FILE_STRUCT_H
# define _FILE_STRUCT_H

# define ID_LEN 20
# define NAME_LEN 30
# define STREEN_LEN 35
# define CITY_LEN 20
# define ZIP_LEN 10
# define COUNTRY_LEN 10
# define EMAIL_LEN 30
# define PHONE_LEN 20
# define IMAGE_NAME_LEN 45
# define IMAGE_LEN 1000

typedef struct bin_file_s {
  char id[ID_LEN];                   // A "unique" id for each person in the file. It may
                                     // not actually be unique, but it is good enough for now.

  char fname[NAME_LEN];              // First name (given name)
  char mname[NAME_LEN];              // Middle name
  char lname[NAME_LEN];              // Last name (family name)
  char street[STREEN_LEN];           // Street address
  char city[CITY_LEN];               // City name
  char zip[ZIP_LEN];                 // The Postal code
  char country_code[COUNTRY_LEN];    // The country code for the address.

  char email[EMAIL_LEN];             // An email address
  char phone[PHONE_LEN];             // Phone number.

  char image_name[IMAGE_NAME_LEN];   // The name of the image file (if used)
                                     // If there is no image file, this should be all blanks.
  char image[IMAGE_LEN];             // The content of the image file (if used).
                                     // If there is no image file, this should be all blanks.
} bin_file_t;

#endif // _FILE_STRUCT_H
