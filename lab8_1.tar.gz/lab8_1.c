#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <pthread.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <stdint.h>
#include <math.h>

#define SetBit(A,k)    ( A[(k/32)] |= (1 << (k%32)) )
#define ClearBit(A,k)  ( A[(k/32)] &= ~(1 << (k%32)) )
#define TestBit(A,k)   ( A[(k/32)] & (1<<(k%32))  )

//static pthread_mutex_t prime_nums;

//#define Marsbar uint8_t

typedef struct BitBlock_s {
    uint8_t bits;
    pthread_mutex_t mutex;
} BitBlock_t;

typedef struct thread_args_s{
    int sizeofarray;
    int totnumbers;
    int totthreads;
    int id;
} thread_args_t;


void show_help(void);

void start(int numbers, int verbose);

void SetBit_1(BitBlock_t *A, unsigned k);

int TestBit_1(BitBlock_t *A, unsigned k);

void start_threaded(int numthreads, int numbers, int verbose);

void * run_threads(void * void_arg);

int isPrime(int val);


BitBlock_t *BitOHoney = NULL;


int main(int argc, char * argv[])
{
    int i =0;
    int numberthreads=1;
    int totalnumbers=10240;
    int verbose=0;
    int opt;

    while((opt=getopt(argc,argv,"t:u:hv"))!=-1)
    {
        switch(opt)
        {
        case 'h':
            show_help();
            break;
        case 'v':
            verbose=1;
            break;
        case 't':
            numberthreads=atoi(optarg);
            if(numberthreads>42)
            {
                numberthreads=42;
            }
            break;
        case 'u':
            totalnumbers=atoi(optarg);
            break;
        }
    }
    if(verbose==1)
    {
        fprintf(stderr, "Number of Threads for this run is %d, Number of total numbers ran too is %d."
                ,numberthreads,totalnumbers);
    }

    {
        BitBlock_t junkie;
        unsigned blaa = ((totalnumbers / (sizeof(junkie.bits))) + 1);
        unsigned blaa7;

        BitOHoney = (BitBlock_t *) malloc(blaa * sizeof(BitBlock_t));
        for (blaa7 = 0; blaa7 < blaa; blaa7++) {
            pthread_mutex_init(&(BitOHoney[blaa7].mutex), NULL);
            BitOHoney[blaa7].bits = 0x00000000;
        }
    }



    if(numberthreads>1)
    {
        start_threaded(numberthreads, totalnumbers, verbose);

        for(i =2; i<totalnumbers; ++i)
        {
            if(TestBit_1(BitOHoney,i)==0)
            {
                printf("%d\n",i);
            }
        }

    }
    else if(numberthreads==1)
    {
        start(totalnumbers, verbose);
    }
    else
    {
        if(verbose==1)
        {
            fprintf(stderr, "Problem with number of threads");
        }
    }

    return 0;
}

// k is the value setting bit.
// k = 42 ==> set bit 42 to 1;
void SetBit_1(BitBlock_t *A, unsigned k)
{
//    BitBlock_t junkie;
    {
        int i = k / ((sizeof(A[0].bits)) * 8);
        int pos = k % ((sizeof(A[0].bits)) * 8);

        unsigned int flag = 1;

        flag = flag << pos;
        pthread_mutex_lock(&A[i].mutex);
         if(!isPrime(k))
         {
//       printf("%d\n",k);
            A[i].bits =  A[i].bits | flag;
         }
        pthread_mutex_unlock(&A[i].mutex);
    }
}

int TestBit_1(BitBlock_t *A, unsigned k)
{
    int i = k / ((sizeof(A[0].bits)) * 8);
    int pos = k % ((sizeof(A[0].bits)) * 8);
    unsigned int flag = 1;
    int temp=0;
    flag = flag << pos;

    pthread_mutex_lock(&A[i].mutex);

    if(A[i].bits & flag)
    {
        temp=1;
    }  
  
    pthread_mutex_unlock(&A[i].mutex);

    return temp;
}


void show_help(void)
{
    printf("Welcome to Optimus Prime Help\n");
    printf("In this program we will be storing all numbers that aren't a prime number in a bit array\n");
    printf("On the command line you have a few options including -v -h -t -u\n");
    printf("The -h command will bring you to this and quit the program");
    printf("The -v command will put you in verbose mode and will give you extra information in stderr\n");
    printf("The -t command MUST BE FOLLOWED BY a numeric value. If not specified default is 1\n");
    printf("The max number of threads on this system is 42 so if you put in more then that it will be reset to 42\n");
    printf("The -u commnad MUST BE FOLLOW BY a numeric value. If not specified default is 10, 240\n");
    exit(0);
}
//The purpose of this function is to get the number of prime numbers from 2 too numbers
//we are going to store those numbers inside a bit_array we calculated all the prime numbers in the
//bit array are going to ahve the value of 0 then we are going to loop and print out all the prime numbers
// to stdout

void start(int numbers, int verbose)
{
    int size = numbers/32+1;//this will have to be the size of your bit array;
    int bit_array[size];  // our bit array that has our value
    int i=0;
    int j=0;
    clock_t start;
    clock_t stop;
    double single=0.0;
    
    while(i < size) //this going to loop through and set all your values to zero
    {
        bit_array[i] = 0 & bit_array[i];
        ++i;
    }
    
    i=2; // starting number our first prime number;
    start=clock();
    while(i < numbers)
    {
        if(!TestBit(bit_array,i)) // this will test the current bit of your loop if 0 then go into if
        {
            printf("%d\n",i);
            //printf("\n");
//            fprintf(writeout,"%d",i);
            // fprintf(std,"%d",i);
                j=i+i;//start on the number after i
                while(j<numbers) //loop through all numbers after j until numbers
                { 
                  SetBit(bit_array,j);
                  j = j+i;
                }
        }
        ++i; //increment i for next value in loop
    }
     
    stop=clock();
    single  = ((double) (stop - start)/ (double) CLOCKS_PER_SEC);
    fprintf(stderr,"Time it took to run one thread through %d numbers was \t%10.4f seconds\n", numbers, single);
}

void start_threaded(int numthreads, int numbers, int verbose)
{
    int size =numbers/32+1; // going to have the same size array if single or multiple threads
//    int bit_array[size]; // make the bit array
//    int threadbits = numbers/numthreads+1; //this is going to give you the amount of bits each thread will cover
//    BitBlock_t bitsperlock;
    clock_t start;
      clock_t stop;
    int i=0;
    int j=0;
    int ret;
    int id=2;
    pthread_t * threads;
    thread_args_t * thread_data;
    double single=0.0;
    threads = (pthread_t *) malloc(numthreads * sizeof(pthread_t));
    thread_data = (thread_args_t *) malloc(numthreads * sizeof(thread_args_t));

    start=clock();
    
    for(j=0; j<numthreads; j++)
    {
        thread_data[j].totnumbers=numbers;
        thread_data[j].totthreads=numthreads;
        thread_data[j].sizeofarray=size;
        thread_data[j].id=id;
        id++;
        ret= pthread_create(&(threads[j]), NULL , run_threads, (void *) &thread_data[j]);
       if(ret!=0)
       {
            if(verbose==1)
            {
                 fprintf(stderr, "Problem creating thread");
            }
            printf("Problem creating thread %d exiting", i);
            exit(0);
       }
    }
    
    for(j=0; j< numthreads; j++)
    {
       pthread_join(threads[j], NULL);
       if(verbose==1)
       {
          fprintf(stderr, "Thread %d rejoined", j);
       }
    }
    stop=clock();
    single  = ((double) (stop - start)/ (double) CLOCKS_PER_SEC);
    fprintf(stderr,"Time it took to run one thread through %d numbers was \t%10.4f seconds\n", numbers, single);


    i++;
    
    free(threads);
    free(thread_data);

}

void * run_threads(void * void_arg)
{
    thread_args_t * arg = (thread_args_t *) void_arg;
    int i=arg->id;
    int j=0;
    while(i<arg->totnumbers)
    {       
        // printf("enter while loop\n");
        if(TestBit_1(BitOHoney, i)==0)
        {
           
            // if(isPrime(i))
            // {
                j=i+i;
                while(j<arg->totnumbers)
                {
                    //                  printf("made it to set bit\n");
                    SetBit_1(BitOHoney, j);
                    j+=i;
                }
                //        }
         }
        i+=arg->totthreads;
    }

//    printf("exited\n");
//    pthread_exit(EXIT_SUCCESS);
    return NULL;
}

int isPrime(int val)
{
    int incrementer = 3;
    int check = 0;
    int notprime = 0;

    if((val%2)==0)
    {
        notprime=0; 
    }
    else
    {
        while(incrementer <= ceil(sqrt(val)) && check == 0)
        {
            if((val % incrementer) == 0)
            {
                notprime = 0;
                check = 1;
            }
            incrementer += 2;
        }
    }
    return notprime;
}
