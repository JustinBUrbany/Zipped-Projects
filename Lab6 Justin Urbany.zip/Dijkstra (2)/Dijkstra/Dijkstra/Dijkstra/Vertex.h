/*************************************************************
* Author:		Justin Urbany
* Filename:		Vertex.h
* Date Created: 3/10/17
* Modifications:	3/13/17 -Added Comments
**************************************************************/
#pragma once
#include <list>
using std::list;
template<typename V, typename E>
class Edge;
template<typename V, typename E>
class Graph;
/************************************************************************
* Class: Vertex
*
* Purpose: Creates a Vertex in the graph which contains a List of edges
*		that are all the ways to get to another vertex
*
* Manager functions:
*	Vertex():
*	Vertex(V data):
*	Vertex(const Vertex & copy):
*	operator =(const Vertex & rhs):
*	~Vertex():
* Data_members:
*		int m_position
*		bool m_processed
*		V m_data
*		list<Edge<V, E>*> m_list
*************************************************************************/
template<typename V, typename  E>
class Vertex
{
public:
	Vertex();
	Vertex(V data);
	Vertex(const Vertex & copy);
	Vertex<V, E> & operator =(const Vertex & rhs);
	V getData();
	list<Edge<V, E>*> & getList();
	void SetData(V data);
	void Setprocessed(bool processed);
	bool Getprocessed() const;
	void Setposition(int pos);
	int Getposition();
	~Vertex();

private:
	int m_position;
	bool m_processed;
	V m_data;
	list<Edge<V, E>*> m_List;

};
/**********************************************************************
* Purpose:Create a Vertex
*
* Precondtion:none
*
* Postcondition:Vertex created m_processed is false
*
************************************************************************/
template<typename V, typename E>
inline Vertex<V, E>::Vertex() : m_processed(false)
{
}
/**********************************************************************
* Purpose: Create a vertex initialize m-data
*
* Precondtion: Passes in the data
*
* Postcondition: Vertex made
*
************************************************************************/
template <typename V, typename E>
Vertex<V, E>::Vertex(V data) : m_data(data), m_processed(false)
{
}
/**********************************************************************
* Purpose:Create a copy of a vertex
*
* Precondtion: Pass in the vertex to copy
*
* Postcondition: both vertexs are the same
*
************************************************************************/
template <typename V, typename E>
Vertex<V, E>::Vertex(const Vertex& copy) : m_processed(copy.m_processed), m_List(copy.m_List), m_data(copy.m_data)
{
}
/**********************************************************************
* Purpose:Create a copy of a vertex
*
* Precondtion: Pass in the vertex to copy
*
* Postcondition: both vertexs are the same
*
************************************************************************/
template<typename T, typename Y>
inline Vertex<T, Y>& Vertex<T, Y>::operator=(const Vertex & rhs)
{
	if (this != &rhs)
	{
		m_processed = rhs.m_processed;
		m_data = rhs.m_data;
		m_List = rhs.m_List;
	}
	return *this;
}
/**********************************************************************
* Purpose: Get the data of the vertex
*
* Precondtion:none 
*
* Postcondition: return the data member of the vertex
*
************************************************************************/
template <typename V, typename E>
V Vertex<V, E>::getData()
{
	return m_data;
}
/**********************************************************************
* Purpose: Get the Edge list of the vertex
*
* Precondtion: none
*
* Postcondition: Return the list in the vertex
*
************************************************************************/
template <typename V, typename E>
list<Edge<V, E>*> & Vertex<V, E>::getList()
{
	return m_List;
}
/**********************************************************************
* Purpose: Set the data to the passed in data
*
* Precondtion: pass in data
*
* Postcondition: m_data is the same as data
*
************************************************************************/
template <typename V, typename E>
void Vertex<V, E>::SetData(V data)
{
	m_data = data;
}
/**********************************************************************
* Purpose: Set the processed of the Vertex
*
* Precondtion: Pass in a bool value
*
* Postcondition: m_processed is equal to passed in processed
*
************************************************************************/
template<typename V, typename E>
inline void Vertex<V, E>::Setprocessed(bool processed)
{
	m_processed = processed;
}
/**********************************************************************
* Purpose: Get the processed value
*
* Precondtion: none
*
* Postcondition: return the processed value
*
************************************************************************/
template <typename V, typename E>
bool Vertex<V, E>::Getprocessed() const
{
	return m_processed;
}
/**********************************************************************
* Purpose: Set the position of the vertex element
*
* Precondtion: pass in the position
*
* Postcondition: position is set
*
************************************************************************/
template <typename V, typename E>
void Vertex<V, E>::Setposition(int pos)
{
	m_position = pos;
}
/**********************************************************************
* Purpose: Get the position of the vertex element
*
* Precondtion: none
*
* Postcondition: Return the position of the vertex
*
************************************************************************/
template <typename V, typename E>
int Vertex<V, E>::Getposition()
{
	return m_position;
}
/**********************************************************************
* Purpose: Destory a vertex
*
* Precondtion: Called when going out of scope
*
* Postcondition: have deleted the list of edges
*
************************************************************************/
template<typename V, typename E>
inline Vertex<V, E>::~Vertex()
{
	Edge<V, E> * temp = nullptr;
	typename list<Edge<V, E> *>::iterator traversal = m_List.begin();

	while (traversal != m_List.end())
	{
		temp = (*traversal);
		++traversal;
		delete temp;
		temp = nullptr;
	}

	m_List.clear();
}
