/*************************************************************
* Author:		Justin Urbany
* Filename:		Edge.h
* Date Created: 3/10/17
* Modifications:	3/13/17 -Added Comments
**************************************************************/
#pragma once
#include "Vertex.h"
/************************************************************************
* Class: Edge
*
* Purpose: Creates an Edge which has a weight and a destination
*			connects a vertex to another vertex
*
* Manager functions:
*	Edge():
*	Edge(E data, double Weight, Vertex<V, E> * destination):
*	Edge(const Edge & copy):
*	operator =(const Edge<V, E> & rhs):
*
* Data_members:
*	E m_data holds the name of the edge
*	double m_weight holds the weight of the edge
*	Vertex<V, E> * m_destination holds the end point of the edge
*************************************************************************/
template<typename V, typename E>
class Edge
{
public:
	Edge();
	Edge(E data, double Weight, Vertex<V, E> * destination);
	Edge(const Edge & copy);
	Edge<V, E> & operator=(const Edge<V, E> & rhs);
	Vertex<V, E> * getDest();
	E getData();
	double getWeight();
	~Edge();

private:
	E m_data;
	double m_weight;
	Vertex<V, E> * m_destination;

};
/**********************************************************************
* Purpose: Create an edge
*
* Precondtion: none
*
* Postcondition: weight is zero destination is nullptr
*
************************************************************************/
template <typename V, typename E>
::Edge<V, E>::Edge() : m_weight(0), m_destination(nullptr)
{
}
/**********************************************************************
* Purpose: Create an edge
*
* Precondtion: pass in data weight and destination
*
* Postcondition: data weight and destination are all intialized
*
************************************************************************/
template<typename V, typename E>
inline Edge<V, E>::Edge(E data, double Weight, Vertex<V, E> * destination) : m_data(data), m_weight(Weight), m_destination(destination)
{
}
/**********************************************************************
* Purpose: Create a copy of an Edge
*
* Precondtion: pass in the Edge you want to make a copy of
*
* Postcondition: Both edges are the same
*
************************************************************************/
template <typename V, typename E>
Edge<V, E>::Edge(const Edge& copy)
{
	*this = copy;
}
/**********************************************************************
* Purpose: Assign one edge to another edge
*
* Precondtion: pass in the edge to assign
*
* Postcondition: both edges are the same
*
************************************************************************/
template <typename V, typename E>
Edge<V, E>& Edge<V, E>::operator=(const Edge<V, E>& rhs)
{
	if (this != &rhs)
	{
		m_weight = rhs.m_weight;
		m_destination = rhs.m_destination;
		m_data = rhs.m_data;
	}
	return *this;
}
/**********************************************************************
* Purpose: get the destination of an edge
*
* Precondtion:called from an edge
*
* Postcondition: return the destination of that edge
*
************************************************************************/
template <typename V, typename E>
Vertex<V, E>* Edge<V, E>::getDest()
{
	return m_destination;
}
/**********************************************************************
* Purpose: return the data of an edge
*
* Precondtion: none
*
* Postcondition: data of the edge returned
*
************************************************************************/
template <typename V, typename E>
E Edge<V, E>::getData()
{
	return m_data;
}
/**********************************************************************
* Purpose: get the weight of an edge
*
* Precondtion:none
*
* Postcondition: return the weight of an edge
*
************************************************************************/
template <typename V, typename E>
double Edge<V, E>::getWeight()
{
	return m_weight;
}
/**********************************************************************
* Purpose: destroy an edge
*
* Precondtion: called when out of scope
*
* Postcondition: Edge no longer exists
*
************************************************************************/
template<typename V, typename E>
inline Edge<V, E>::~Edge()
{

}
