/*************************************************************
* Author:		Justin.Urbany
* Filename:		Stub.cpp
* Date Created:	2/8/2017
* Modifications:	2/13/17 -Added Comments
**************************************************************/
#define _CRTDB_MAP_ALLOC
#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>
#include "Graph.h"
using std::setprecision;
using std::ifstream;
using std::getline;
using std::cout;
using std::cin;
using std::endl;
using std::string;
using std::stod;
#include <crtdbg.h>
/*************************************************************
*
* Lab/Assignment: Lab 6-djikstras
*
* Overview:
*	This program will read from a file and create a graph. Then
*	a user will enter a starting point which will then djikstras
*	shortest path algorithm will be preformed on that starting
*	point.
* Input:
*   The input will have the user select a starting city. If
*	the city is valid it will then have them select a ending
*	city
*
* Output:
*   The of this program will take the user input show the
*	shortest path form one point to another and tell the
*	user how much time it will take to get from point a
*	to point b
************************************************************/
template <typename T>
void Display(T data); 
void ReadFile(Graph<string, string> & map);
void Dijkstra(Graph<string, string> & map);
void process(Graph<string, string> & map, string start);
/**********************************************************************
* Purpose: Driver for djikstras
*
* Precondtion: none
*
* Postcondition: if file exists and user wants run djikstras djikstras is run
*
************************************************************************/
int main()
{
	_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);

	Graph<string, string> som;
	ReadFile(som);
	Dijkstra(som);

	return 0;
}
/**********************************************************************
* Purpose: Display passed in data
*
* Precondtion: pass in the data
*
* Postcondition: data is on the screen
*
************************************************************************/
template<typename T>
void Display(T data)
{
	cout << data << endl;
}
/**********************************************************************
* Purpose: ReadFile gets the data from the file populates a graph
*
* Precondtion: Pass in the graph by refrence
*
* Postcondition: If file has data and is valid populate the graph
*
************************************************************************/
void ReadFile(Graph<string, string> & map)
{
	string vertex1;
	string vertex2;
	string edge;
	string edgeweight;
	double getweight = 0.00;
	ifstream readfile;
	readfile.open("Data.txt");

	if(readfile.is_open())
	{
		while (!readfile.eof())
		{
			getline(readfile, vertex1,',');
			map.InsertVertex(vertex1);
			getline(readfile, vertex2, ',');
			map.InsertVertex(vertex2);
			getline(readfile, edge, ',');
			getline(readfile, edgeweight);
			getweight = stod(edgeweight);
			if(edge=="I-5")
			{
				getweight = getweight / 65;
			}
			else
			{
				getweight = getweight / 55;
			}
			map.InsertEdge(vertex1, vertex2, edge, getweight);
		}
		readfile.close();
	}
	else
	{
		cout << "Error opening File" << endl;
	}
}
/**********************************************************************
* Purpose: get the user input if valid calls the process
*
* Precondtion: passes in the graph
*
* Postcondition: Loops while user want to preform djikstras
*
************************************************************************/
void Dijkstra(Graph<string, string>& map)
{
	string startpoint;
	string endpoint;
	int selection = -1;
	list<Vertex<string, string>*> temp = map.getGraph();
	typename list<Vertex<string, string>*>::iterator traversal = temp.begin();
	while(selection != 2)
	{
		if (!map.isEmpty())
		{
		/*	cout << "Here are all the locations on your map"<<endl;
			map.BreadthFirst(Display);*/
			while (selection != 2 && selection != 1)
			{
				cout << "Enter 1 to get path from a to b or 2 to quit: ";
				cin >> selection;
				if(selection != 2 && selection != 1)
				{
					cout << "Invalid selection" << endl;
				}
			}
			if(selection==1)
			{
				cout << "Enter in starting point: ";
				cin.clear();
				cin.ignore(cin.rdbuf()->in_avail());
				getline(cin, startpoint);
				cin.clear();
				traversal = temp.begin();
				while(traversal != temp.end() && (*traversal)->getData() != startpoint)
				{
					++traversal;
				}
				if(traversal != temp.end() &&(*traversal)->getData() == startpoint)
				{

					process(map, startpoint);
				}
				else
				{
					cout << "Invalid startpoint";
				}
				selection = -1;
			}
		}
		else
		{
			cout << "Graph is empty can't use Dijkstras";
			selection = 2;
		}
	}
}
/**********************************************************************
* Purpose: Make an array of predecessor and distances 
*
* Precondtion: passes in the graph and the starting name
*
* Postcondition: return the weight of an edge
*
************************************************************************/
void process(Graph<string, string>& map, string start)
{
	map.Reset();  //
	list<Vertex<string, string>*> temp = map.getGraph();
	list<Edge<string, string>*> edgetemp;
	Vertex<string, string> * tempvertex;
	Vertex<string, string> * beingprocessed;
	Vertex<string, string> * next;
	Vertex<string, string> * beginning;
	typename list<Vertex<string, string>*>::iterator traversal = temp.begin();
	typename list<Edge<string, string>*>::iterator edgetraversal;
	bool finished = false;
	int position = 0;
	bool firstrun = true;
	while (traversal != temp.end())
	{
		(*traversal)->Setposition(position);
		++position;
		++traversal;
	}


	double distance[36] = { -1.000 };  //intialize the distance array
	for (int k = 0; k < 36; ++k)
	{
		distance[k] = -1;
	}
	Vertex<string, string> * predecessor[36] = { nullptr }; // intialize the predecessor array
	traversal = temp.begin();

	while (traversal != temp.end() && (*traversal)->getData() != start) // get the start of the starting point
	{
		++traversal;
	}

	distance[(*traversal)->Getposition()] = 0;  //set the starting distance point to 0

	beingprocessed = (*traversal); // put the current vertex into being processed
	beginning = beingprocessed;
	while (!finished)
	{
		edgetemp = beingprocessed->getList();  //get the list of edges that are at that vertex that isn't processed
		edgetraversal = edgetemp.begin();  //set an iterator to go through those edges
		while (edgetraversal != edgetemp.end())  //go through each element of the edge list
		{
			if ((*edgetraversal)->getDest()->Getprocessed() == false) //if the element is not processed
			{
				tempvertex = (*edgetraversal)->getDest(); // put the destination into a tempvertex
				if (distance[tempvertex->Getposition()] == -1 || distance[tempvertex->Getposition()] > (*edgetraversal)->getWeight() + distance[beingprocessed->Getposition()]) //check if the distance is less then
				{
					distance[tempvertex->Getposition()] = (*edgetraversal)->getWeight() + distance[beingprocessed->Getposition()]; //if it is less then set the new distance
					predecessor[tempvertex->Getposition()] = beingprocessed; // set the new predecessor
				}
			}
			++edgetraversal; //increment 
		}
		beingprocessed->Setprocessed(true); //set the vertex to processed


		traversal = temp.begin(); //get a new traversal

		for (int i = 0; i < 36; ++i) // go through all predecessor and distances
		{
			if (predecessor[i] != nullptr && (*traversal)->Getprocessed() == false)//see what has been set and not processed
			{
				if (firstrun == true)
				{
					beingprocessed = (*traversal);
					firstrun = false;
				}
				else
				{
					if (distance[beingprocessed->Getposition()] > distance[i])
					{
						beingprocessed = (*traversal);
					}
				}
			}
			++traversal;
		}
		firstrun = true;

		traversal = temp.begin();
		finished = true;
		while (traversal != temp.end() && finished == true)
		{
			if (!(*traversal)->Getprocessed())
			{
				finished = false;
			}
			++traversal;
		}
	}

	bool getroute = true;
	string endpoint;
	int selection = -1;
	Vertex < string, string> * findbegin;

	int pathlength=0;
	
	while (getroute == true)
	{
		cout << "Where would you like to go?(enter city): ";
		cin.clear();
		cin.ignore(cin.rdbuf()->in_avail());
		getline(cin, endpoint);
		cin.clear();
		traversal = temp.begin();
		while (traversal != temp.end() && (*traversal)->getData() != endpoint) // get the start of the starting point
		{
			++traversal;
		}
		if (endpoint != start)
		{
			if (traversal != temp.end() && (*traversal)->getData() == endpoint)
			{
				cout << "The time in hours it will take for you to get from " << start << " to " << endpoint << " is " << setprecision(3) << distance[(*traversal)->Getposition()]<<" hours."<<endl;
				Vertex<string, string> * path[36] = { nullptr };
				findbegin = predecessor[(*traversal)->Getposition()];
				path[pathlength] = (*traversal);
				while (findbegin->getData() != beginning->getData())
				{
					++pathlength;
					path[pathlength] = findbegin;
					findbegin = predecessor[findbegin->Getposition()];
				}
				++pathlength;
				path[pathlength] = findbegin;
				for(int p = pathlength; p>0; --p)
				{
					cout << "Go from " << path[p]->getData() << " to " << path[p - 1]->getData() << ' ';
					edgetemp = path[p]->getList();
					edgetraversal = edgetemp.begin();
					while(edgetraversal != edgetemp.end() && (*edgetraversal)->getDest()->getData() != path[p-1]->getData())
					{
						++edgetraversal;
					}
					if (edgetraversal != edgetemp.end())
					{
						cout << "via " << (*edgetraversal)->getData() << endl;
					}
				}
				pathlength = 0;
			}
			else
			{
				cout << "That is an Invalid enpoint" << endl;
			}
		}
		else
		{
			cout << "I hope it will take no time to get from " << start << " to " << endpoint;
		}
		cout << "Would you like to get another ending location(1 yes/2 no): ";
		cin >> selection;
		if(selection !=1 )
		{
			getroute = false;
		}

	}
}