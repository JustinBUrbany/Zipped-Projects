#pragma once
#include <vector>
#include <list>
#include "Exception.h"
using std::vector;
using std::list;
using std::pair;

template<typename K, typename V>
class HashTable
{
public:
	HashTable();
	HashTable(int size);
	HashTable(const HashTable & copy);
	HashTable & operator=(const HashTable & rhs);
	~HashTable();

	void Insert(K key, V value);
	void setHash(int(*has)(K key));
	V operator [](K key);
	void Delete(K key);
	void traverse(void(*visit)(V value));
private:
	
	vector<list<pair<K, V>>> m_table;
	int (*Hashfnc)(K key);
	int getKeyLocation(K key);
	void rehash(int(*has)(K key));
};

template<typename K, typename V>
inline HashTable<K, V>::HashTable()
{
	m_table.resize(10);
}

template<typename K, typename V>
inline HashTable<K, V>::HashTable(int size)
{
	m_table.resize(size);
}

template<typename K, typename V>
inline HashTable<K, V>::HashTable(const HashTable & copy)
{
	m_table = copy.m_table;
}

template<typename K, typename V>
inline HashTable<K, V> & HashTable<K, V>::operator=(const HashTable & rhs)
{
	if (this != &rhs)
	{
		m_table = rhs.m_table;
	}
	return *this;
}

template<typename K, typename V>
inline HashTable<K, V>::~HashTable()
{
}

template<typename K, typename V>
inline void HashTable<K, V>::Insert(K key, V value)
{
	pair<K, V> newpair(key,value);
	try
	{
		int place = getKeyLocation(key);
		m_table[place].push_back(newpair);
	}
	catch (Exception & exception)
	{
		cout << exception.getMessage();
	}
}

template<typename K, typename V>
inline void HashTable<K, V>::setHash(int(*has)(K key))
{
	Hashfnc = has;
	if (!m_table.empty())
	{
		rehash(has);
	}
}

template<typename K, typename V>
inline V HashTable<K, V>::operator[](K key)
{
	int location = getKeyLocation(key);
	typename list<pair<K, V>>::iterator l_iterator=vector[location].begin();

	while (l_iterator != vector[location].end() && (*l_iterator)->first != key)
	{
		l_iterator++;
	}
	if (l_iterator == vector[location].end())
	{
		throw Exception("Not in your table");
	}

	return (*l_iterator)->second;
}

template<typename K, typename V>
inline void HashTable<K, V>::Delete(K key)
{
	int position = getKeyLocation(key);
	vector[position].clear();
}

template<typename K, typename V>
inline void HashTable<K, V>::traverse(void(*visit)(V value))
{

}

template<typename K, typename V>
inline int HashTable<K, V>::getKeyLocation(K key)
{
	int location=0;

	location = Hashfnc(key);
	if (location < 0 || location >= m_table.size())
		throw Exception("OUt of Bounds");

	return location;
}

template<typename K, typename V>
inline void HashTable<K, V>::rehash(int(*has)(K key))
{
	int place = -1;
	vector<list<pair<K, V>>> temp;
	temp.resize(m_table.size());
	typename list<pair<K, V>>::iterator l_iterator;
	for (int i = 0; i < m_table.size(); ++i)
	{
		l_iterator = m_table[i].begin();
		for (; l_iterator != m_table[i].end(); ++i)
		{
			place = getKeyLocation((*l_iterator).first);
			temp[place].push_back((*l_iterator));
		}
	}
	m_table = temp;
}
