#define _CRTDB_MAP_ALLOC
#include <iostream>
#include <string>
#include "HashTable.h"
using std::string;
using std::cout;
using std::cin;
using std::endl;
#include <crtdbg.h>

struct Book
{
	string m_title;
	string m_author;
	int m_pages;
};


int AciiHash(string Key);

int main()
{
	_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);

	Book Hobbit;
	Hobbit.m_title = "Hobbit";
	Hobbit.m_author = "Tolkien";
	Hobbit.m_pages = 512;

	Book HarryPotter;
	HarryPotter.m_title = "Harry Potter";
	HarryPotter.m_author = "Rwoles";
	HarryPotter.m_pages = 345;

	Book WatershipDown;
	WatershipDown.m_title = "WaterShip Down";
	WatershipDown.m_author = "Unknown";
	WatershipDown.m_pages = 463;

	Book BlackPrism;
	BlackPrism.m_title = "Black Prism";
	BlackPrism.m_author = "Brent Weeks";
	BlackPrism.m_pages = 476;
	Book temp = { "C++: An Active Learning Approach", "Randal Albert", 635 };
	Book temp1 = { "Rodeo for Dummies", "Calvin Caldwell", 1 };
	Book temp2 = { "temp2", "Todd", 1 };
	Book temp3 = { "temp3", "Jesse", 1 };
	Book temp4 = { "temp4", "Troy", 1 };
	Book temp5 = { "temp5", "Mark", 1 };
	Book temp6 = { "temp6", "Phil", 1 };
	Book temp7 = { "temp7", "Soo", 1 };
	Book temp8 = { "temp8", "Lucy", 1 };
	Book temp9 = { "temp9", "Mandy", 1 };
	Book temp10 = { "temp10", "Alicia", 1 };
	Book temp11= { "temp11", "LAST PERSON", 1 };
	HashTable<string, Book> table1;
	HashTable<string, Book> table(10);

	table.setHash(AciiHash);

	table.Insert("7063757234", Hobbit);
	table.Insert("11", HarryPotter);
	table.Insert("7063757233",WatershipDown);
	table.Insert("7063757232", BlackPrism);
	table.Insert("7063757235",temp);
	table.Insert("7063757236",temp1);
	table.Insert("7063757237",temp2);
	table.Insert("7063757238",temp3);
	table.Insert("7063757239", temp4);
	table.Insert("7063757230", temp5);
	table.Insert("7063757241", temp6);
	table.Insert("7063757242", temp7);
	table.Insert("7063757243", temp8);
	table.Insert("7063757244", temp9);
	table.Insert("7063757245", temp10);
	table.Insert("7063757246", temp11);

	cout << table["0763757233"].m_title << endl;
	cout << table["7063757233"].m_title << endl;
	cout << table["7063757234"].m_title << endl;


	

	return 0;
}

int AciiHash(string Key)
{
	int location = 0;

	for (int i = 0; i < Key.length(); i++)
	{
		location += static_cast<int>(Key[i]);
	}

	location %= 10;

	return location;
}